'use strict';
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const {once} = require('node:events');
(async () => {
 const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'madhuban-test-'));
 const probe = net.createServer(); probe.listen(0,'127.0.0.1'); await once(probe,'listening'); const port=probe.address().port; await new Promise(r=>probe.close(r));
 const child = spawn(process.execPath,['server/server.js'],{env:{...process.env,PORT:String(port),NODE_ENV:'production',DATA_DIR:temporary,UPLOAD_DIR:path.join(temporary,'uploads'),SESSION_SECRET:crypto.randomBytes(32).toString('hex'),ADMIN_PASSWORD:crypto.randomBytes(24).toString('hex'),SMTP_HOST:'',SMTP_USER:'',SMTP_PASS:'',SEND_AUTOREPLY:'false',COOKIE_SECURE:'false',ENABLE_CSP:'true'},stdio:'ignore'});
 const stopped = once(child,'exit');
 try {
  const origin='http://127.0.0.1:'+port;
  for(let i=0;i<100;i++){try{if((await fetch(origin+'/api/health')).ok)break;}catch{} await new Promise(r=>setTimeout(r,50));}
  for(const route of ['/',...fs.readdirSync('public').filter(f=>f.endsWith('.html')).map(f=>'/'+f),'/privacy-policy','/terms-and-conditions','/favicon.ico','/favicon-32.png','/favicon-192.png','/apple-touch-icon.png','/images/social-preview.png','/robots.txt']) {
   const res=await fetch(origin+route);assert.equal(res.status,200,route);
   if(route.endsWith('.html')) {const html=await res.text();assert.match(html,/og:site_name" content="Madhuban Group/);assert.match(html,/rel="icon"/);}
  }
  for(const route of ['enquiry','contact','careers']) {
   const invalid=await fetch(origin+'/api/'+route,{method:'POST',body:new URLSearchParams({name:'x',email:'bad',phone:'1'})});assert.equal(invalid.status,400);assert.equal((await invalid.json()).ok,false);
   let body;
   if(route==='careers') {body=new FormData();body.set('cv',new Blob(['%PDF-1.4\nQA fixture'],{type:'application/pdf'}),'qa.pdf');}
   else body=new URLSearchParams();
   for(const [key,val] of Object.entries({name:'Engineering QA',phone:'1234567890',email:'qa@example.invalid',message:'Isolated local QA submission'}))body.set(key,val);
   const valid=await fetch(origin+'/api/'+route,{method:'POST',body});assert.equal(valid.status,201);assert.equal((await valid.json()).ok,true);
  }
  const badCV=new FormData();badCV.set('cv',new Blob(['bad'],{type:'text/plain'}),'bad.txt');assert.equal((await fetch(origin+'/api/careers',{method:'POST',body:badCV})).status,400);
  assert.equal((await fetch(origin+'/admin',{redirect:'manual'})).status,302);
  assert.equal((await fetch(origin+'/admin/submissions/1/cv',{redirect:'manual'})).status,302);
  const DB=require('better-sqlite3');const db=new DB(path.join(temporary,'madhuban.db'),{readonly:true});assert.equal(db.prepare('SELECT count(*) AS n FROM submissions').get().n,3);db.close();assert.equal(fs.readdirSync(path.join(temporary,'uploads')).length,1);
  console.log('PASS: production-mode startup, 14 pages, legal routes, icon/SEO assets, validation and persisted submissions for all 3 APIs, CV rejection/storage, admin access protection. SMTP disabled; isolated temporary storage.');
 } finally {child.kill('SIGTERM');await stopped;fs.rmSync(temporary,{recursive:true,force:true});}
})().catch(err=>{console.error(err);process.exitCode=1;});
