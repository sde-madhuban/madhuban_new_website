'use strict';
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const {once} = require('node:events');
(async () => {
 const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'madhuban-test-'));
 const probe = net.createServer(); probe.listen(0,'127.0.0.1'); await once(probe,'listening'); const port=probe.address().port; await new Promise(r=>probe.close(r));
 const adminPassword = crypto.randomBytes(24).toString('hex');
 let accessLog = '';
 const child = spawn(process.execPath,['server/server.js'],{env:{...process.env,PORT:String(port),NODE_ENV:'production',DATA_DIR:temporary,UPLOAD_DIR:path.join(temporary,'uploads'),SESSION_SECRET:crypto.randomBytes(32).toString('hex'),ADMIN_USER:'qa-admin',ADMIN_PASSWORD:adminPassword,TRUST_PROXY:'0',SMTP_HOST:'',SMTP_USER:'',SMTP_PASS:'',SEND_AUTOREPLY:'false',COOKIE_SECURE:'false',ENABLE_CSP:'true'},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data', data => { accessLog += data.toString(); });
 child.stderr.on('data', data => { accessLog += data.toString(); });
 const stopped = once(child,'exit');
 try {
  const origin='http://127.0.0.1:'+port;
  for(let i=0;i<100;i++){try{if((await fetch(origin+'/api/health')).ok)break;}catch{} await new Promise(r=>setTimeout(r,50));}
  for(const route of ['/',...fs.readdirSync('public').filter(f=>f.endsWith('.html')).map(f=>'/'+f),'/privacy-policy','/terms-and-conditions','/favicon.ico','/favicon-32.png','/favicon-192.png','/apple-touch-icon.png','/images/social-preview.png','/robots.txt']) {
   const res=await fetch(origin+route);assert.equal(res.status,200,route);
   if(route.endsWith('.html')) {const html=await res.text();assert.match(html,/og:site_name" content="Madhuban Group/);assert.match(html,/rel="icon"/);}
  }
  for(const route of ['enquiry','contact','careers']) {
   const invalid=await fetch(origin+'/api/'+route,{method:'POST',body:new URLSearchParams({name:'x',email:'bad',phone:'1'})});assert.equal(invalid.status,400);assert.equal((await invalid.json()).ok,false);
   let body;
   if(route==='careers') {body=new FormData();body.set('cv',new Blob(['%PDF-1.4\nQA fixture'],{type:'application/pdf'}),'qa.pdf');}
   else body=new URLSearchParams();
   for(const [key,val] of Object.entries({name:'Engineering <script>alert(1)</script>',phone:'1234567890',email:'qa@example.invalid',message:'Isolated local QA submission'}))body.set(key,val);
   const valid=await fetch(origin+'/api/'+route,{method:'POST',body});assert.equal(valid.status,201);assert.equal((await valid.json()).ok,true);
  }
  const badCV=new FormData();badCV.set('cv',new Blob(['bad'],{type:'text/plain'}),'bad.txt');assert.equal((await fetch(origin+'/api/careers',{method:'POST',body:badCV})).status,400);
  assert.equal((await fetch(origin+'/admin',{redirect:'manual'})).status,302);
  assert.equal((await fetch(origin+'/admin/submissions/1/cv',{redirect:'manual'})).status,302);
  const DB=require('better-sqlite3');const db=new DB(path.join(temporary,'madhuban.db'),{readonly:true});assert.equal(db.prepare('SELECT count(*) AS n FROM submissions').get().n,3);db.close();assert.equal(fs.readdirSync(path.join(temporary,'uploads')).length,1);
  const loginPage = await fetch(origin+'/admin/login');
  assert.equal(loginPage.headers.get('cache-control'),'no-store');
  const oldCookie=loginPage.headers.get('set-cookie').split(';')[0];
  const oldToken=(await loginPage.text()).match(/name="_csrf" value="([^"]+)"/)[1];
  const loginBody=new URLSearchParams({username:'qa-admin',password:adminPassword});
  assert.equal((await fetch(origin+'/admin/login',{method:'POST',body:loginBody,redirect:'manual',headers:{Cookie:oldCookie}})).status,403);
  loginBody.set('_csrf',oldToken);
  const login=await fetch(origin+'/admin/login',{method:'POST',body:loginBody,redirect:'manual',headers:{Cookie:oldCookie}});
  assert.equal(login.status,302); const cookie=login.headers.get('set-cookie').split(';')[0];assert.notEqual(cookie,oldCookie);
  const admin=await fetch(origin+'/admin?q=PRIVATE_SEARCH_SENTINEL',{headers:{Cookie:cookie}});
  assert.equal(admin.headers.get('cache-control'),'no-store');
  const adminHTML=await (await fetch(origin+'/admin',{headers:{Cookie:cookie}})).text();
  assert.ok(adminHTML.includes('&lt;script&gt;'));assert.ok(!adminHTML.includes('<script>alert'));
  const token=adminHTML.match(/name="_csrf" value="([^"]+)"/)[1];
  for(const action of ['/admin/logout','/admin/submissions/1/status','/admin/submissions/1/delete']) {
    assert.equal((await fetch(origin+action,{method:'POST',body:new URLSearchParams({status:'handled'}),headers:{Cookie:cookie},redirect:'manual'})).status,403);
  }
  assert.equal((await fetch(origin+'/admin/submissions/1/status',{method:'POST',body:new URLSearchParams({_csrf:token,status:'handled'}),headers:{Cookie:cookie},redirect:'manual'})).status,302);
  const downloaded=await fetch(origin+'/admin/submissions/3/cv',{headers:{Cookie:cookie}});assert.equal(downloaded.status,200);assert.match(downloaded.headers.get('content-disposition'),/^attachment/);assert.equal(downloaded.headers.get('cache-control'),'no-store');assert.match(await downloaded.text(),/^%PDF-/);
  const confirmation=await fetch(origin+'/admin/submissions/1/delete',{headers:{Cookie:cookie}});assert.equal(confirmation.status,200);assert.match(await confirmation.text(),/Delete permanently/);
  const snapshotDB=new DB(path.join(temporary,'madhuban.db'),{readonly:true});await snapshotDB.backup(path.join(temporary,'backup.db'));snapshotDB.close();
  const recovered=new DB(path.join(temporary,'backup.db'),{readonly:true});assert.equal(recovered.prepare('SELECT count(*) AS n FROM submissions').get().n,3);assert.equal(recovered.pragma('integrity_check',{simple:true}),'ok');recovered.close();
  const forged=new FormData();for(const [key,val] of Object.entries({name:'QA',phone:'1234567890',email:'qa@example.invalid'}))forged.set(key,val);forged.set('cv',new Blob(['not a PDF'],{type:'application/pdf'}),'fake.pdf');assert.equal((await fetch(origin+'/api/careers',{method:'POST',body:forged})).status,400);
  const tooMany=new FormData();for(let i=0;i<14;i++)tooMany.set('field'+i,'test');assert.equal((await fetch(origin+'/api/careers',{method:'POST',body:tooMany})).status,400);
  const oversized=new FormData();oversized.set('cv',new Blob(['%PDF-',new Uint8Array(5*1024*1024)],{type:'application/pdf'}),'large.pdf');assert.equal((await fetch(origin+'/api/careers',{method:'POST',body:oversized})).status,400);
  const malformed=await fetch(origin+'/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:'{'});assert.equal(malformed.status,400);
  const tooLarge=await fetch(origin+'/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'a'.repeat(110000)})});assert.equal(tooLarge.status,413);
  const csp=(await fetch(origin+'/')).headers.get('content-security-policy');assert.ok(csp.includes("script-src 'self'"));assert.ok(!csp.includes('unsafe-eval'));assert.ok(!csp.includes('cdn.tailwindcss.com'));
  assert.equal((await fetch(origin+'/uploads/qa.pdf')).status,404);assert.equal((await fetch(origin+'/data/madhuban.db')).status,404);
  let limited=false;for(let i=0;i<32;i++){const response=await fetch(origin+'/api/enquiry',{method:'POST',body:new URLSearchParams()});if(response.status===429){limited=true;break;}}assert.ok(limited);
  assert.equal((await fetch(origin+'/admin/submissions/1/delete',{method:'POST',body:new URLSearchParams({_csrf:token}),headers:{Cookie:cookie},redirect:'manual'})).status,302);
  assert.equal((await fetch(origin+'/admin/logout',{method:'POST',body:new URLSearchParams({_csrf:token}),headers:{Cookie:cookie},redirect:'manual'})).status,302);
  assert.equal((await fetch(origin+'/admin',{headers:{Cookie:cookie},redirect:'manual'})).status,302);
  await new Promise(r=>setTimeout(r,100));assert.ok(!accessLog.includes('PRIVATE_SEARCH_SENTINEL'));assert.ok(!accessLog.includes(adminPassword));
  console.log('PASS: login/logout/status/delete CSRF, session rotation/invalidation, escaped stored input, authenticated CV download, no-store, confirmation page, isolated SQLite backup restore/integrity, spoofed/oversize/overpart uploads, parser limits, CSP, private-file isolation, rate limiting and query redaction.');
 } finally {child.kill('SIGTERM');await stopped;fs.rmSync(temporary,{recursive:true,force:true});}
})().catch(err=>{console.error(err);process.exitCode=1;});
