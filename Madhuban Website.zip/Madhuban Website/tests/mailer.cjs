'use strict';
const assert = require('node:assert/strict');
const nodemailer = require('nodemailer');
(async () => {
  // Exercise the upgraded MIME implementation entirely in memory; no network/mail delivery.
  const stream = nodemailer.createTransport({ streamTransport: true, buffer: true, newline: 'unix' });
  const original = nodemailer.createTransport;
  const sent = [];
  nodemailer.createTransport = options => {
    assert.equal(options.disableFileAccess, true);
    assert.equal(options.disableUrlAccess, true);
    assert.equal(options.connectionTimeout, 10000);
    return { verify: async () => true, sendMail: async message => { sent.push(message); return stream.sendMail(message); } };
  };
  Object.assign(process.env, { SMTP_HOST: 'offline.invalid', SMTP_USER: 'team@example.invalid', SMTP_PASS: 'test-only', MAIL_FROM: 'team@example.invalid', NOTIFY_TO: 'team@example.invalid', SEND_AUTOREPLY: 'true' });
  const mailer = require('../server/mailer');
  try {
    mailer.init();
    const fixture={type:'enquiry', name:'<script>alert(1)</script>', email:'person@example.invalid', phone:'1234567890', message:'<img src=x onerror=alert(1)>', extra:{interest:'Office'}, created_at:'test', ip:'127.0.0.1'};
    const message = await mailer.notifyTeam(fixture); await mailer.sendAutoReply(fixture);
    assert.equal(sent.length,2); assert.ok(sent[0].html.includes('&lt;script&gt;'));assert.ok(!sent[0].html.includes('<script>'));assert.equal(sent[0].replyTo,fixture.email);assert.equal(sent[1].to,fixture.email);assert.ok(Buffer.isBuffer(message.message));
    console.log('PASS: upgraded mailer MIME generation, escaped body, reply-to/auto-reply routing, transport limits; no external email sent.');
  } finally { nodemailer.createTransport = original; }
})().catch(error=>{console.error(error);process.exitCode=1;});
