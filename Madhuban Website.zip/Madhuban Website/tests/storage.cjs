'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const DB = require('better-sqlite3');
const {main,verify} = require('../scripts/backup.cjs');
const {privateDirectory} = require('../server/storage');
(async()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'madhuban-storage-'));
  const prior=process.env.UPLOAD_DIR;
  try {
    const data=path.join(root,'data'), uploads=path.join(root,'uploads'), snap=path.join(root,'snapshot'), restored=path.join(root,'restored');
    fs.mkdirSync(data);fs.mkdirSync(uploads);process.env.UPLOAD_DIR=uploads;
    const db=new DB(path.join(data,'madhuban.db'));
    db.exec("CREATE TABLE submissions(id INTEGER, cv_filename TEXT); INSERT INTO submissions VALUES(1,'cv.pdf'); CREATE TABLE sessions(secret TEXT); INSERT INTO sessions VALUES('test-session');");db.close();
    fs.writeFileSync(path.join(uploads,'cv.pdf'),'%PDF-1.4 test');
    await assert.rejects(main(['create',data,snap]));
    await main(['create',data,snap,'--offline']);verify(snap);
    await assert.rejects(main(['create',data,snap,'--offline']));
    await main(['restore',snap,restored,'--offline']);
    const check=new DB(path.join(restored,'madhuban.db'));
    assert.equal(check.prepare('SELECT count(*) n FROM submissions').get().n,1);
    assert.equal(check.prepare("SELECT count(*) n FROM sqlite_master WHERE name='sessions'").get().n,0);check.close();
    assert.equal(fs.readFileSync(path.join(restored,'uploads/cv.pdf'),'utf8'),'%PDF-1.4 test');
    fs.writeFileSync(path.join(snap,'uploads/cv.pdf'),'tampered');assert.throws(()=>verify(snap));
    await assert.rejects(main(['restore',snap,path.join(root,'bad'),'--offline']));assert.ok(!fs.existsSync(path.join(root,'bad')));
    fs.unlinkSync(path.join(uploads,'cv.pdf'));await assert.rejects(main(['create',data,path.join(root,'missing'),'--offline']));assert.ok(!fs.existsSync(path.join(root,'missing')));
    if(process.platform!=='win32') {
      fs.symlinkSync(path.resolve('public'),path.join(root,'public-link'));
      assert.throws(()=>privateDirectory(path.join(root,'public-link','private-test')));
      fs.symlinkSync(path.join(data,'madhuban.db'),path.join(uploads,'cv.pdf'));
      await assert.rejects(main(['create',data,path.join(root,'symlink'),'--offline']));
    }
    console.log('Storage/backup tests passed: recovery, session exclusion, tampering, missing files, overwrite prevention and symlink rejection.');
  } finally {if(prior===undefined)delete process.env.UPLOAD_DIR;else process.env.UPLOAD_DIR=prior;fs.rmSync(root,{recursive:true,force:true});}
})().catch(err=>{console.error(err);process.exitCode=1;});
