/* ============================================================
   Madhuban Group — Shared UI (header, footer, menus, modals)
   Injected into every page so the nav lives in ONE place.
   Set the active page via <body data-page="...">.
   ============================================================ */
(function () {
  "use strict";

  var CONTACT = {
    phone: "020 6688 0000",
    phoneHref: "02066880000",
    email: "contact@madhuban.biz",
    whatsapp: "912066880000",
    address: "Amar Madhuban Tech Park, Baner–Balewadi, Pune, Maharashtra, India"
  };

  var EXPERTISE = [
    { key: "commercial",  href: "commercial.html",  title: "Commercial",  desc: "Grade-A IT & office spaces in Pune", ico: "building" },
    { key: "industrial",  href: "industrial.html",  title: "Industrial",  desc: "Ind-Biz parks & warehousing", ico: "factory" },
    { key: "hospitality", href: "hospitality.html", title: "Hospitality", desc: "Where the Madhuban story began", ico: "cup" },
    { key: "residential", href: "residential.html", title: "Residential", desc: "Homes designed for modern living", ico: "home" },
    { key: "upcoming",    href: "upcoming.html",    title: "Upcoming",    desc: "A resort & food mall in the making", ico: "star" }
  ];

  var NAV = [
    { key: "home",    href: "index.html",   label: "Home" },
    { key: "about",   href: "about.html",   label: "About" },
    { key: "expertise", label: "Expertise", mega: true },
    { key: "awards",  href: "awards.html",  label: "Awards" },
    { key: "careers", href: "careers.html", label: "Careers" },
    { key: "contact", href: "contact.html", label: "Contact Us" }
  ];

  // ---- SVG icon set ----
  var I = {
    peak: '<svg class="brand-peak" viewBox="0 0 48 48" fill="none"><path d="M24 5 44 40H26.5L24 30 21.5 40H4L24 5Z" fill="#e0413a"/><path d="M24 5 33 40h-6.5L24 30 21.5 40H15L24 5Z" fill="#1a1a1a"/></svg>',
    caret: '<svg class="nav-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 9l6 6 6-6"/></svg>',
    search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
    menu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
    close: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>',
    building: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 8h1M14 8h1M9 12h1M14 12h1M9 16h6"/></svg>',
    factory: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M3 21V10l6 4V10l6 4V6l6 15z"/><path d="M3 21h18"/></svg>',
    cup: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M5 8h11v5a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5z"/><path d="M16 9h2a2 2 0 0 1 0 4h-2M5 21h13"/></svg>',
    home: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M4 11 12 4l8 7"/><path d="M6 10v10h12V10"/><path d="M10 20v-6h4v6"/></svg>',
    star: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17.9 6.6 20l1-6.1L3.2 9.5l6.1-.9z"/></svg>',
    phone: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>',
    mail: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
    pin: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',
    wa: '<svg width="30" height="30" viewBox="0 0 32 32" fill="currentColor"><path d="M16 3C9.4 3 4 8.3 4 15c0 2.3.7 4.5 1.8 6.4L4 29l7.9-1.8A12 12 0 0 0 16 27c6.6 0 12-5.3 12-12S22.6 3 16 3zm0 21.8c-1.9 0-3.7-.5-5.3-1.4l-.4-.2-4 .9.9-3.9-.3-.4A9.8 9.8 0 0 1 6.2 15C6.2 9.6 10.6 5.2 16 5.2S25.8 9.6 25.8 15 21.4 24.8 16 24.8zm5.4-7.3c-.3-.1-1.8-.9-2-1s-.5-.1-.7.1-.8 1-1 1.2-.4.2-.7.1a8 8 0 0 1-2.4-1.5 9 9 0 0 1-1.6-2c-.2-.3 0-.5.1-.6l.5-.5.3-.5c.1-.2 0-.4 0-.5l-1-2.3c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4a3.4 3.4 0 0 0-1 2.5c0 1.5 1 2.9 1.2 3.1.1.2 2.2 3.4 5.3 4.7.7.3 1.3.5 1.8.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4z"/></svg>',
    fb: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M14 9h3V5h-3c-2.2 0-4 1.8-4 4v2H7v4h3v6h4v-6h3l1-4h-4V9c0-.6.4-1 1-1z"/></svg>',
    ig: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>',
    li: '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M6.9 8H3.7v12h3.2zM5.3 3.5A1.9 1.9 0 1 0 5.3 7a1.9 1.9 0 0 0 0-3.5zM20.3 20h-3.2v-6.3c0-1.5-.5-2.5-1.9-2.5-1 0-1.6.7-1.9 1.4-.1.2-.1.6-.1.9V20H10s.1-10.9 0-12h3.2v1.7c.4-.7 1.2-1.6 3-1.6 2.2 0 3.9 1.4 3.9 4.5z"/></svg>',
    x: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.5 3h3l-6.6 7.5L21.8 21h-5.9l-4.6-6-5.3 6H3l7.1-8L2.6 3h6l4.2 5.5zM16.4 19.2h1.7L7.7 4.7H5.9z"/></svg>'
  };

  function isActive(key, current) {
    if (key === "expertise") return EXPERTISE.some(function (e) { return e.key === current; });
    return key === current;
  }

  // ---------- HEADER ----------
  function renderHeader(current) {
    var links = NAV.map(function (n) {
      if (n.mega) {
        var items = EXPERTISE.map(function (e) {
          return '<a class="mega-item" href="' + e.href + '">' +
            '<span class="mega-ico">' + I[e.ico] + '</span>' +
            '<span><span class="mega-t">' + e.title + '</span><span class="mega-d">' + e.desc + '</span></span></a>';
        }).join("");
        return '<div class="mega-wrap has-mega">' +
          '<a href="commercial.html" class="nav-link ' + (isActive("expertise", current) ? "active" : "") + '">' + n.label + I.caret + '</a>' +
          '<div class="mega"><div class="mega-grid">' + items + '</div>' +
          '<div style="margin-top:.6rem;border-top:1px solid var(--line);padding-top:.8rem;display:flex;justify-content:space-between;align-items:center">' +
          '<span style="font-size:.82rem;color:var(--muted)">Explore every division of the Madhuban Group</span>' +
          '<a href="about.html" style="font-size:.85rem;font-weight:600;color:var(--brand);text-decoration:none">Our Story →</a></div></div></div>';
      }
      return '<a class="nav-link ' + (isActive(n.key, current) ? "active" : "") + '" href="' + n.href + '">' + n.label + '</a>';
    }).join("");

    return '' +
      '<div class="nav-shell"><div class="container-x"><div class="nav-inner">' +
        '<a class="brand-mark" href="index.html">' +
          '<img class="brand-logo brand-logo--dark" src="images/madhuban-logo.png" alt="Madhuban Group"></a>' +
        '<nav class="nav-links" aria-label="Primary navigation">' + links + '</nav>' +
        '<div class="nav-actions">' +
          '<button class="icon-btn desktop-only" id="searchOpen" aria-label="Search">' + I.search + '</button>' +
          '<button class="btn btn-primary desktop-only" id="enquireOpen">Enquire Now</button>' +
          '<button class="icon-btn hamburger" id="drawerOpen" aria-label="Menu" aria-expanded="false" aria-controls="drawer">' + I.menu + '</button>' +
        '</div>' +
      '</div></div></div>';
  }

  // ---------- MOBILE DRAWER ----------
  function renderDrawer(current) {
    var links = NAV.map(function (n) {
      if (n.mega) {
        var subs = EXPERTISE.map(function (e) {
          return '<a class="sub" href="' + e.href + '">— ' + e.title + '</a>';
        }).join("");
        return '<a style="cursor:default;color:var(--brand)">Expertise</a>' + subs;
      }
      return '<a href="' + n.href + '" class="' + (n.key === current ? "" : "") + '">' + n.label + '</a>';
    }).join("");
    return '<div class="drawer-backdrop" id="drawerBackdrop"></div>' +
      '<aside class="drawer" id="drawer" role="dialog" aria-modal="true" aria-label="Navigation menu" inert>' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">' +
          '<a class="brand-mark" href="index.html"><img class="brand-logo brand-logo--dark" src="images/madhuban-logo.png" alt="Madhuban Group" style="height:38px"></a>' +
          '<button class="icon-btn" id="drawerClose" aria-label="Close">' + I.close + '</button></div>' +
        links +
        '<button class="btn btn-primary" id="enquireOpen2" style="width:100%;justify-content:center;margin-top:1.2rem">Enquire Now</button>' +
        '<div style="margin-top:1.2rem;font-size:.85rem;color:var(--muted);line-height:1.7">' +
          I.phone + ' ' + CONTACT.phone + '<br>' + I.mail + ' ' + CONTACT.email + '</div>' +
      '</aside>';
  }

  // ---------- FOOTER ----------
  function renderFooter() {
    var quick = [
      ["About Us", "about.html"], ["Commercial", "commercial.html"], ["Industrial", "industrial.html"],
      ["Residential", "residential.html"], ["Clients", "clients.html"], ["Careers", "careers.html"],
      ["CSR", "csr.html"], ["Contact", "contact.html"],
      ["Privacy Policy", "/privacy-policy"], ["Terms & Conditions", "/terms-and-conditions"]
    ].map(function (q) { return '<li><a href="' + q[1] + '">' + q[0] + '</a></li>'; }).join("");

    return '<div class="site-footer">' +
      '<div class="container-x" style="padding-top:4rem;padding-bottom:2.5rem">' +
        '<div style="display:grid;grid-template-columns:1.4fr 1fr 1.3fr;gap:2.5rem" class="foot-grid">' +
          '<div>' +
            '<a class="brand-mark" href="index.html" style="margin-bottom:1rem;display:inline-block">' +
              '<img class="brand-logo" src="images/madhuban-logo.png" alt="Madhuban Group" style="height:66px"></a>' +
            '<p style="color:var(--on-dark);font-size:.92rem;line-height:1.75;max-width:34ch;margin:0 0 1.2rem">Shaping futures together since 1997 — a Pune-based business house across commercial, industrial, hospitality and residential real estate.</p>' +
          '</div>' +
          '<div>' +
            '<h4 style="color:var(--surface);font-size:1rem;margin:0 0 1.1rem">Quick Links</h4>' +
            '<ul style="list-style:none;padding:0;margin:0;display:grid;grid-template-columns:1fr 1fr;gap:.6rem;font-size:.9rem">' + quick + '</ul>' +
          '</div>' +
          '<div>' +
            '<h4 style="color:var(--surface);font-size:1rem;margin:0 0 1.1rem">Get in Touch</h4>' +
            '<ul style="list-style:none;padding:0;margin:0;font-size:.9rem;line-height:1.6;color:var(--on-dark)">' +
              '<li style="display:flex;gap:.6rem;margin-bottom:.9rem"><span style="color:var(--brand);margin-top:2px">' + I.pin + '</span><span>' + CONTACT.address + '</span></li>' +
              '<li style="display:flex;gap:.6rem;margin-bottom:.9rem"><span style="color:var(--brand)">' + I.phone + '</span><a href="tel:' + CONTACT.phoneHref + '">' + CONTACT.phone + '</a></li>' +
              '<li><a href="https://wa.me/' + CONTACT.whatsapp + '" target="_blank" rel="noopener">Chat on WhatsApp</a></li>' +
              '<li style="display:flex;gap:.6rem"><span style="color:var(--brand)">' + I.mail + '</span><a href="mailto:' + CONTACT.email + '">' + CONTACT.email + '</a></li>' +
            '</ul>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div style="border-top:1px solid rgba(255,255,255,.08)"><div class="container-x" style="padding:1.4rem 1.25rem;display:flex;justify-content:space-between;flex-wrap:wrap;gap:.6rem;font-size:.82rem;color:var(--on-dark)">' +
        '<span>© ' + '2024' + ' Madhuban Group. All rights reserved.</span>' +
        '<span>Crafted with care · Powered by HorseTech Services</span>' +
      '</div></div>' +
      '</div>';
  }

  // ---------- MODALS (search + enquire) ----------
  function renderModals() {
    var enquire =
      '<div class="modal-backdrop" id="enquireModal" role="dialog" aria-modal="true" aria-label="Enquire Now" inert><div class="modal">' +
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.4rem">' +
          '<div><span class="eyebrow">Enquire Now</span><h3 style="font-size:1.5rem;margin:.6rem 0 0">Let’s shape the future, together</h3></div>' +
          '<button class="icon-btn" data-modal-close aria-label="Close">' + I.close + '</button></div>' +
        '<p style="color:var(--muted);font-size:.9rem;margin:.4rem 0 1.3rem">Tell us what you’re looking for and our team will reach out within one business day.</p>' +
        '<form class="js-form" data-form="Enquiry">' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;margin-bottom:.8rem">' +
            '<input class="field" name="name" placeholder="Full name" required>' +
            '<input class="field" name="phone" placeholder="Phone" required>' +
          '</div>' +
          '<input class="field" type="email" name="email" placeholder="Email address" required style="margin-bottom:.8rem">' +
          '<select class="field" name="interest" style="margin-bottom:.8rem"><option value="">I’m interested in…</option><option>Commercial space</option><option>Industrial / warehousing</option><option>Residential home</option><option>Hospitality / partnership</option><option>Careers</option><option>Other</option></select>' +
          '<textarea class="field" name="message" rows="3" placeholder="Your message" style="margin-bottom:1rem;resize:vertical"></textarea>' +
          '<button class="btn btn-primary" type="submit" style="width:100%;justify-content:center">Send Enquiry</button>' +
        '</form>' +
      '</div></div>';

    var search =
      '<div class="modal-backdrop" id="searchModal" role="dialog" aria-modal="true" aria-label="Search Madhuban" inert><div class="modal" style="max-width:600px">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">' +
          '<h3 style="font-size:1.2rem;margin:0">Search Madhuban</h3>' +
          '<button class="icon-btn" data-modal-close aria-label="Close">' + I.close + '</button></div>' +
        '<div style="position:relative"><span style="position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:var(--muted)">' + I.search + '</span>' +
          '<input class="field" id="searchInput" aria-label="Search Madhuban" placeholder="Try “Tech Park”, “Residential”, “Careers”…" style="padding-left:2.8rem"></div>' +
        '<div id="searchResults" style="margin-top:1rem;display:flex;flex-direction:column;gap:.3rem"></div>' +
      '</div></div>';

    return enquire + search;
  }

  var SEARCH_INDEX = [
    ["Home", "index.html", "Shaping futures together"],
    ["About Us", "about.html", "Vision, mission, values & leadership"],
    ["Commercial", "commercial.html", "Grade-A IT office spaces in Pune"],
    ["Industrial", "industrial.html", "Ind-Biz Tata Industrial Park, Chakan"],
    ["Hospitality", "hospitality.html", "Madhuban Kaleidoscope — since 1997"],
    ["Residential", "residential.html", "Ekunj Residency & 7 Avenues, Balewadi"],
    ["Upcoming", "upcoming.html", "Lonavala resort & Samruddhi food mall"],
    ["Clients", "clients.html", "Oyo, Zolo, Indiabulls, Tata, Smartworks…"],
    ["Awards", "awards.html", "Best IT Park — Amar Madhuban Tech Park"],
    ["CSR", "csr.html", "Solar, tree plantation & blood donation"],
    ["Careers", "careers.html", "Be a part of Madhuban"],
    ["Contact", "contact.html", "020 6688 0000 · contact@madhuban.biz"]
  ];

  // ---------- WIRING ----------
  var activeDialog = null;
  var returnFocus = null;
  function open(el) {
    if (!el) return;
    el.classList.add("open");
    document.body.style.overflow = "hidden";
    if (el.matches('[role="dialog"]')) {
      returnFocus = document.activeElement;
      activeDialog = el;
      el.inert = false;
      document.querySelectorAll('#site-header, main, #site-footer, .wa-float').forEach(function (node) { node.inert = true; });
      el.querySelectorAll("svg").forEach(function (svg) { svg.setAttribute("aria-hidden", "true"); });
      if (el.id === "drawer") document.getElementById("drawerOpen").setAttribute("aria-expanded", "true");
      var first = el.querySelector('input, button, a[href]');
      if (first) first.focus();
    }
  }
  function close(el) {
    if (!el) return;
    el.classList.remove("open");
    if (el === activeDialog) {
      el.inert = true;
      activeDialog = null;
      document.querySelectorAll('#site-header, main, #site-footer, .wa-float').forEach(function (node) { node.inert = false; });
      document.getElementById("drawerOpen").setAttribute("aria-expanded", "false");
      if (returnFocus && returnFocus.isConnected) returnFocus.focus();
    }
    if (!document.querySelector('.modal-backdrop.open, .drawer.open')) document.body.style.overflow = "";
  }

  function wire() {
    var header = document.getElementById("site-header");
    var footer = document.getElementById("site-footer");
    var current = document.body.getAttribute("data-page") || "home";

    if (header) header.innerHTML = renderHeader(current);
    if (footer) footer.innerHTML = renderFooter();

    var overlays = document.createElement("div");
    overlays.innerHTML = renderDrawer(current) + renderModals() +
      '<a class="wa-float" href="https://wa.me/' + CONTACT.whatsapp + '" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">' + I.wa + '</a>';
    document.body.appendChild(overlays);

    var drawer = document.getElementById("drawer");
    var drawerBd = document.getElementById("drawerBackdrop");
    var enquireModal = document.getElementById("enquireModal");
    var searchModal = document.getElementById("searchModal");

    function on(id, ev, fn) { var e = document.getElementById(id); if (e) e.addEventListener(ev, fn); }
    on("drawerOpen", "click", function () { open(drawer); open(drawerBd); });
    on("drawerClose", "click", function () { close(drawer); close(drawerBd); });
    drawerBd && drawerBd.addEventListener("click", function () { close(drawer); close(drawerBd); });
    on("searchOpen", "click", function () { open(searchModal); var s=document.getElementById("searchInput");if(s)s.focus(); });
    on("enquireOpen", "click", function () { open(enquireModal); });
    on("enquireOpen2", "click", function () { close(drawer); close(drawerBd); open(enquireModal); });

    document.querySelectorAll("[data-modal-close]").forEach(function (b) {
      b.addEventListener("click", function () { close(b.closest(".modal-backdrop")); });
    });
    document.querySelectorAll(".modal-backdrop").forEach(function (m) {
      m.addEventListener("click", function (e) { if (e.target === m) close(m); });
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { document.querySelectorAll(".modal-backdrop.open,.drawer.open,.drawer-backdrop.open").forEach(close); }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key !== "Tab" || !activeDialog) return;
      var nodes = Array.from(activeDialog.querySelectorAll('a[href], button, input, select, textarea, [tabindex="0"]')).filter(function (node) { return !node.disabled && node.tabIndex >= 0 && node.getClientRects().length; });
      var first = nodes[0], last = nodes[nodes.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
    document.querySelectorAll('.nav-links a, .drawer a[href]').forEach(function (link) {
      if (link.getAttribute('href') === current + '.html' || (current === 'home' && link.getAttribute('href') === 'index.html')) link.setAttribute('aria-current', 'page');
    });
    var megaWrap = document.querySelector('.mega-wrap');
    if (megaWrap) {
      megaWrap.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') { megaWrap.querySelector('a').focus(); megaWrap.classList.add('mega-dismissed'); }
      });
      megaWrap.addEventListener('mouseleave', function () { megaWrap.classList.remove('mega-dismissed'); });
      megaWrap.addEventListener('focusout', function (event) { if (!megaWrap.contains(event.relatedTarget)) megaWrap.classList.remove('mega-dismissed'); });
    }
    // Associate existing labels and add persistent labels to the enquiry fields.
    document.querySelectorAll('.js-form').forEach(function (form, formIndex) {
      form.querySelectorAll('.field').forEach(function (field, index) {
        field.id = field.id || 'form-' + formIndex + '-field-' + index;
        var label = field.previousElementSibling;
        if (!label || label.tagName !== 'LABEL') {
          label = document.createElement('label');
          label.className = 'lbl';
          label.textContent = field.name === 'interest' ? 'Area of interest' : field.placeholder || field.name;
          field.before(label);
          if (field.parentElement.style.display === 'grid') {
            var wrap = document.createElement('div');
            field.before(wrap); wrap.append(label, field);
          }
        }
        label.htmlFor = field.id;
        if (field.name === 'phone') { field.type = 'tel'; field.autocomplete = 'tel'; }
        if (field.name === 'name' || field.name === 'email') field.autocomplete = field.name;
      });
      var status = document.createElement('p');
      status.className = 'form-status'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
      form.appendChild(status);
      var privacy = document.createElement('p');
      privacy.className = 'form-privacy';
      privacy.innerHTML = 'Read how form information is handled in our <a href="/privacy-policy">Privacy Policy (draft)</a>.';
      form.appendChild(privacy);
    });

    // scrolled shadow
    var shell = header && header.querySelector(".nav-shell");
    if (shell) {
      var onScroll = function () { shell.classList.toggle("scrolled", window.scrollY > 8); };
      onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    }

    // search behaviour
    var si = document.getElementById("searchInput");
    var sr = document.getElementById("searchResults");
    function paint(list) {
      sr.innerHTML = list.map(function (r) {
        return '<a class="search-result" href="' + r[1] + '" style="display:block;padding:.8rem 1rem;border-radius:12px;text-decoration:none;transition:background .2s">' +
          '<div style="font-weight:600;color:var(--charcoal)">' + r[0] + '</div>' +
          '<div style="font-size:.82rem;color:var(--muted)">' + r[2] + '</div></a>';
      }).join("") || '<p style="color:var(--muted);font-size:.9rem;padding:.5rem 1rem">No matches — try another term.</p>';
    }
    if (si) {
      paint(SEARCH_INDEX);
      si.addEventListener("input", function () {
        var q = si.value.trim().toLowerCase();
        paint(SEARCH_INDEX.filter(function (r) { return (r[0] + " " + r[2]).toLowerCase().indexOf(q) > -1; }));
      });
    }

    // form handling → posts to the Node backend (/api/*)
    var ENDPOINTS = { Enquiry: "/api/enquiry", Message: "/api/contact", Application: "/api/careers" };
    document.querySelectorAll(".js-form").forEach(function (f) {
      // Inject a hidden honeypot field for bot filtering (real users never fill it).
      if (!f.querySelector('input[name="website"]')) {
        var hp = document.createElement("input");
        hp.type = "text"; hp.name = "website"; hp.tabIndex = -1; hp.autocomplete = "off";
        hp.setAttribute("aria-hidden", "true");
        hp.style.cssText = "position:absolute;left:-9999px;width:1px;height:1px;opacity:0";
        f.appendChild(hp);
      }

      f.addEventListener("submit", function (e) {
        e.preventDefault();
        var status = f.querySelector(".form-status");
        if (status) status.textContent = "";
        var kind = f.getAttribute("data-form") || "Message";
        var endpoint = ENDPOINTS[kind] || "/api/contact";
        var btn = f.querySelector('button[type="submit"]');
        var label = btn ? btn.innerHTML : null;
        function restore() { if (btn) { btn.disabled = false; btn.innerHTML = label; } }
        if (btn) { btn.disabled = true; btn.innerHTML = "Sending…"; }

        if (location.protocol === "file:") {
          restore();
          var offlineMessage = "This form needs the website server. Your details have not been sent.";
          if (status) status.textContent = offlineMessage;
          toast(offlineMessage);
          return;
        }

        var isMultipart = kind === "Application"; // careers form carries a CV file
        var body = isMultipart ? new FormData(f) : new URLSearchParams(new FormData(f));

        fetch(endpoint, { method: "POST", body: body })
          .then(function (r) {
            return r.json().then(function (data) {
              if (!r.ok && data.ok) return { ok: false };
              return data;
            }).catch(function () { return { ok: false, errors: ["The server did not confirm your submission. Your details have been kept; please try again."] }; });
          })
          .then(function (res) {
            restore();
            if (res && res.ok) {
              close(f.closest(".modal-backdrop")); f.reset();
              var successMessage = res.message || (kind + " sent! Our team will contact you within one business day.");
              if (status) status.textContent = successMessage;
              toast(successMessage);
            } else {
              if (status) status.textContent = (res && res.errors && res.errors.join(" ")) || "Something went wrong. Please try again.";
              toast((res && res.errors && res.errors.join(" ")) || "Something went wrong. Please try again.");
            }
          })
          .catch(function () {
            restore();
            if (status) status.textContent = "Network error — please check your connection and try again.";
            toast("Network error — please check your connection and try again.");
          });
      });
    });
  }

  function toast(msg) {
    var t = document.createElement("div");
    t.setAttribute("role", "status"); t.className = "toast"; t.textContent = msg; document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add("show"); });
    setTimeout(function () { t.classList.remove("show"); setTimeout(function () { t.remove(); }, 400); }, 4200);
  }

  window.MadhubanToast = toast;

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", wire);
  else wire();
})();
