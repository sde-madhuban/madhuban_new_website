'use strict';
const fs = require('node:fs');
const path = require('node:path');
const PUBLIC = fs.realpathSync(path.join(__dirname, '..', 'public'));
function inside(parent, child) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel));
}
// Resolve existing ancestors too: a missing child beneath a symlink is not private.
function resolved(target) {
  target = path.resolve(target);
  if (fs.existsSync(target)) return fs.realpathSync(target);
  const parent = path.dirname(target);
  if (parent === target) return target;
  return path.join(resolved(parent), path.basename(target));
}
function privateDirectory(target) {
  const directory = resolved(target);
  if (inside(PUBLIC, directory) || inside(directory, PUBLIC)) {
    throw new Error('Private storage must be separate from the public directory');
  }
  fs.mkdirSync(directory, {recursive: true, mode: 0o700});
  return directory;
}
function regularFile(filename) {
  if (!fs.lstatSync(filename).isFile()) throw new Error('Storage file must be a regular file, not a symbolic link');
  return filename;
}
module.exports = {privateDirectory, regularFile, inside, resolved};
