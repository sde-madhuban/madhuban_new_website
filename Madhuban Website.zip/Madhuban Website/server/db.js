// ============================================================
//  Database layer — SQLite via better-sqlite3
//  One "submissions" table for enquiries, contacts & job applications.
// ============================================================
'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

// DATA_DIR is overridable so production can point it at a persistent disk/volume.
const { privateDirectory, regularFile } = require('./storage');
const DATA_DIR = privateDirectory(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));

const DB_PATH = path.join(DATA_DIR, 'madhuban.db');
for (const suffix of ['', '-wal', '-shm', '-journal']) {
  if (fs.existsSync(DB_PATH + suffix)) regularFile(DB_PATH + suffix);
}
const db = new Database(DB_PATH);
if (process.platform !== 'win32') fs.chmodSync(DB_PATH, 0o600);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS submissions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT    NOT NULL,                       -- enquiry | contact | careers
    name        TEXT    NOT NULL,
    email       TEXT,
    phone       TEXT,
    subject     TEXT,                                   -- interest / subject / role
    message     TEXT,
    extra       TEXT,                                   -- JSON: type-specific fields
    cv_filename TEXT,                                   -- stored file (careers)
    cv_original TEXT,                                   -- applicant's original filename
    status      TEXT    NOT NULL DEFAULT 'new',         -- new | handled
    ip          TEXT,
    user_agent  TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_sub_type   ON submissions(type);
  CREATE INDEX IF NOT EXISTS idx_sub_status ON submissions(status);
  CREATE INDEX IF NOT EXISTS idx_sub_created ON submissions(created_at);
`);

const VALID_TYPES = ['enquiry', 'contact', 'careers'];

const stmts = {
  insert: db.prepare(`
    INSERT INTO submissions (type, name, email, phone, subject, message, extra, cv_filename, cv_original, ip, user_agent)
    VALUES (@type, @name, @email, @phone, @subject, @message, @extra, @cv_filename, @cv_original, @ip, @user_agent)
  `),
  getById: db.prepare(`SELECT * FROM submissions WHERE id = ?`),
  updateStatus: db.prepare(`UPDATE submissions SET status = ? WHERE id = ?`),
  remove: db.prepare(`DELETE FROM submissions WHERE id = ?`),
  countByType: db.prepare(`SELECT type, COUNT(*) AS n FROM submissions GROUP BY type`),
  countNew: db.prepare(`SELECT COUNT(*) AS n FROM submissions WHERE status = 'new'`),
};

function createSubmission(data) {
  if (!VALID_TYPES.includes(data.type)) throw new Error('Invalid submission type');
  const row = {
    type: data.type,
    name: data.name,
    email: data.email || null,
    phone: data.phone || null,
    subject: data.subject || null,
    message: data.message || null,
    extra: data.extra ? JSON.stringify(data.extra) : null,
    cv_filename: data.cv_filename || null,
    cv_original: data.cv_original || null,
    ip: data.ip || null,
    user_agent: data.user_agent || null,
  };
  const info = stmts.insert.run(row);
  return getSubmission(info.lastInsertRowid);
}

function getSubmission(id) {
  const row = stmts.getById.get(id);
  return row ? hydrate(row) : null;
}

// Build a parameterised WHERE clause from filters. Values are bound, never interpolated.
function buildWhere({ type, status, search } = {}) {
  const where = [];
  const params = [];
  if (type && VALID_TYPES.includes(type)) { where.push('type = ?'); params.push(type); }
  if (status === 'new' || status === 'handled') { where.push('status = ?'); params.push(status); }
  if (search && search.trim()) {
    where.push('(name LIKE ? OR email LIKE ? OR phone LIKE ? OR subject LIKE ? OR message LIKE ?)');
    const q = '%' + search.trim() + '%';
    params.push(q, q, q, q, q);
  }
  return { clause: where.length ? ' WHERE ' + where.join(' AND ') : '', params };
}

// Paginated list. Returns { items, total, page, pages, perPage } — no records are silently hidden.
function listSubmissions(filters = {}) {
  const perPage = Math.min(Math.max(Number(filters.perPage) || 25, 1), 200);
  const { clause, params } = buildWhere(filters);
  const total = db.prepare('SELECT COUNT(*) AS n FROM submissions' + clause).get(...params).n;
  const pages = Math.max(Math.ceil(total / perPage), 1);
  const page = Math.min(Math.max(Number(filters.page) || 1, 1), pages);
  const offset = (page - 1) * perPage;
  const items = db
    .prepare('SELECT * FROM submissions' + clause + ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?')
    .all(...params, perPage, offset)
    .map(hydrate);
  return { items, total, page, pages, perPage };
}

function setStatus(id, status) {
  if (status !== 'new' && status !== 'handled') throw new Error('Invalid status');
  return stmts.updateStatus.run(status, id).changes > 0;
}

function deleteSubmission(id) {
  return stmts.remove.run(id).changes > 0;
}

function stats() {
  const counts = { enquiry: 0, contact: 0, careers: 0, total: 0, new: 0 };
  for (const r of stmts.countByType.all()) {
    counts[r.type] = r.n;
    counts.total += r.n;
  }
  counts.new = stmts.countNew.get().n;
  return counts;
}

function hydrate(row) {
  let extra = {};
  if (row.extra) { try { extra = JSON.parse(row.extra); } catch (_) { extra = {}; } }
  return Object.assign({}, row, { extra });
}

module.exports = {
  db,
  VALID_TYPES,
  createSubmission,
  getSubmission,
  listSubmissions,
  setStatus,
  deleteSubmission,
  stats,
};
