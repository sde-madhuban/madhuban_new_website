// ============================================================
//  Madhuban Group — Backend server
//  Serves the static site + handles Enquiry / Contact / Careers
//  forms, stores them in SQLite, emails the team, and provides a
//  password-protected admin dashboard.
// ============================================================
'use strict';

require('dotenv').config();

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const morgan = require('morgan');

const mailer = require('./mailer');
const { validate } = require('./validate');
const { loginPage, dashboardPage, layout, esc } = require('./views/render');
const SqliteStore = require('better-sqlite3-session-store')(session);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
// UPLOAD_DIR is overridable so production can point it at a persistent disk/volume.
const { privateDirectory, regularFile } = require('./storage');
const UPLOAD_DIR = privateDirectory(process.env.UPLOAD_DIR || path.join(__dirname, 'uploads'));
privateDirectory(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const db = require('./db');

// Fail fast in production if secrets are missing or still the shipped placeholders.
if (IS_PROD) {
  const PLACEHOLDERS = ['', 'please-change-to-a-long-random-string', 'insecure-dev-secret-change-me'];
  const problems = [];
  if (!process.env.SESSION_SECRET || PLACEHOLDERS.includes(process.env.SESSION_SECRET)) {
    problems.push('SESSION_SECRET is unset or still the placeholder value');
  }
  if (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD === 'change-this-password') {
    problems.push('ADMIN_PASSWORD is unset or still the placeholder value');
  }
  if (problems.length) {
    console.error('\n  Refusing to start in production:\n   - ' + problems.join('\n   - ') +
      '\n  Set strong values in your environment before deploying.\n');
    process.exit(1);
  }
}

mailer.init();

// Behind an HTTPS-terminating proxy (Render/Railway/nginx), trust it so Express sees the
// real client IP and treats the connection as secure when explicitly configured.
// Trust only an explicitly configured hop count. Default to the direct peer.
if (process.env.TRUST_PROXY) {
  const hops = Number(process.env.TRUST_PROXY);
  if (!Number.isInteger(hops) || hops < 0) throw new Error('TRUST_PROXY must be a non-negative hop count');
  app.set('trust proxy', hops);
}

// ---------- Security headers ----------
app.use(helmet({
  contentSecurityPolicy: process.env.ENABLE_CSP !== 'false' || IS_PROD ? {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      scriptSrcAttr: ["'none'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      upgradeInsecureRequests: IS_PROD ? [] : null,
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
      frameSrc: ['https://www.google.com'],
      connectSrc: ["'self'"],
    },
  } : false,
  crossOriginEmbedderPolicy: false,
}));

// ---------- Access logging ----------
// Do not log query strings (admin searches can contain personal information),
// referrers, user agents, cookie headers or request bodies.
app.use(morgan((tokens, req, res) => JSON.stringify({
  method: req.method,
  path: req.path,
  status: Number(tokens.status(req, res)) || null,
  durationMs: Number(tokens['response-time'](req, res)) || null,
})));

// ---------- Parsers ----------
app.use(express.urlencoded({ extended: false, limit: '100kb', parameterLimit: 30 }));
app.use(express.json({ limit: '100kb' }));

// ---------- Sessions (admin) ----------
// Persisted in SQLite so admin logins survive restarts (no MemoryStore leak/logout).
app.use(session({
  name: 'madhuban.sid',
  store: new SqliteStore({ client: db.db, expired: { clear: true, intervalMs: 15 * 60 * 1000 } }),
  secret: process.env.SESSION_SECRET || 'insecure-dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    // Secure-by-default in production (set COOKIE_SECURE=false only if you deliberately serve over HTTP).
    secure: IS_PROD ? process.env.COOKIE_SECURE !== 'false' : String(process.env.COOKIE_SECURE) === 'true',
    maxAge: 1000 * 60 * 60 * 8, // 8 hours
  },
}));

// ---------- Rate limiters ----------
const formLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, errors: ['Too many submissions from this device. Please try again later.'] },
});
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false });

// ---------- File uploads (CV) ----------
const ALLOWED_EXT = ['.pdf', '.doc', '.docx'];
const ALLOWED_MIME = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, 'cv_' + Date.now() + '_' + crypto.randomBytes(6).toString('hex') + ext);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 12, parts: 13, fieldSize: 16 * 1024, fieldNameSize: 100 }, // 5 MB
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ALLOWED_EXT.includes(ext) && ALLOWED_MIME[ALLOWED_EXT.indexOf(ext)] === file.mimetype) return cb(null, true);
    cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'cv'));
  },
});

function clientIp(req) {
  return (req.ip || req.socket?.remoteAddress || '').replace(/^::ffff:/, '');
}

// ============================================================
//  PUBLIC FORM API
// ============================================================
function removeUpload(req) {
  if (!req.file) return;
  const p = path.join(UPLOAD_DIR, path.basename(req.file.filename));
  if (p.startsWith(UPLOAD_DIR)) fs.promises.unlink(p).catch(() => {});
}

async function processSubmission(type, req, res, extraFields) {
  const body = Object.assign({}, req.body, extraFields || {});
  const result = validate(type, body);

  if (result.spam) {
    // Honeypot tripped — pretend success so bots don't learn, discard silently.
    removeUpload(req); // don't keep a bot's file
    return res.status(200).json({ ok: true, message: 'Thank you.' });
  }
  if (!result.ok) {
    removeUpload(req); // no DB record → don't leave an orphaned file on disk
    return res.status(400).json({ ok: false, errors: result.errors });
  }

  const data = Object.assign(result.data, {
    ip: clientIp(req),
    user_agent: (req.get('user-agent') || '').slice(0, 300),
  });
  if (req.file) {
    data.cv_filename = req.file.filename;
    data.cv_original = req.file.originalname.slice(0, 200);
  }

  let saved;
  try {
    saved = db.createSubmission(data);
  } catch (err) {
    removeUpload(req);
    console.error('[db] insert failed:', err.code || 'DB_ERROR');
    return res.status(500).json({ ok: false, errors: ['Something went wrong saving your message. Please try again.'] });
  }

  // Email is best-effort — never block or fail the user's submission on it.
  mailer.notifyTeam(saved).catch((e) => console.warn('[mailer] notify failed:', e.code || 'SMTP_ERROR'));
  mailer.sendAutoReply(saved).catch((e) => console.warn('[mailer] autoreply failed:', e.code || 'SMTP_ERROR'));

  return res.status(201).json({ ok: true, message: 'Thank you! Our team will contact you within one business day.' });
}

app.post('/api/enquiry', formLimiter, (req, res) => processSubmission('enquiry', req, res));
app.post('/api/contact', formLimiter, (req, res) => processSubmission('contact', req, res));

app.post('/api/careers', formLimiter, (req, res) => {
  upload.single('cv')(req, res, (err) => {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE'
        ? 'Your CV is too large (max 5 MB).'
        : 'Please attach a valid CV (PDF, DOC or DOCX, max 5 MB).';
      return res.status(400).json({ ok: false, errors: [msg] });
    }
    // Client-supplied MIME is not evidence of file content. This is a signature
    // check, not malware scanning or full Office/PDF structural validation.
    try {
    if (req.file) {
      const bytes = Buffer.alloc(8);
      const descriptor = fs.openSync(req.file.path, 'r');
      try { fs.readSync(descriptor, bytes, 0, 8, 0); } finally { fs.closeSync(descriptor); }
      const ext = path.extname(req.file.originalname).toLowerCase();
      const signatures = {
        '.pdf': bytes.subarray(0, 5).equals(Buffer.from('%PDF-')),
        '.doc': bytes.equals(Buffer.from('d0cf11e0a1b11ae1', 'hex')),
        '.docx': bytes.subarray(0, 4).equals(Buffer.from('504b0304', 'hex')),
      };
      if (!signatures[ext]) {
        removeUpload(req);
        return res.status(400).json({ ok: false, errors: ['The CV content does not match its file type. Please upload a PDF, DOC or DOCX document.'] });
      }
    }
    } catch (err) {
      removeUpload(req);
      console.error('[upload] read failed:', err.code || 'UPLOAD_ERROR');
      return res.status(500).json({ ok: false, errors: ['Unable to read your CV. Please try again.'] });
    }
    processSubmission('careers', req, res);
  });
});

// Public liveness only — no business data leaked to anonymous callers.
app.get('/api/health', (req, res) => res.json({ ok: true }));

// ============================================================
//  ADMIN
// ============================================================
// Strict CSP for admin pages (they use only inline <style>, no JS) — a hard
// backstop against any XSS even though every value is already HTML-escaped.
app.use('/admin', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"
  );
  next();
});
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.redirect('/admin/login');
}

function ensureCsrf(req) {
  if (!req.session.csrf) req.session.csrf = crypto.randomBytes(16).toString('hex');
  return req.session.csrf;
}

function checkCsrf(req, res, next) {
  if (req.body && req.body._csrf && req.session.csrf && safeEqual(req.body._csrf, req.session.csrf)) return next();
  return res.status(403).send('Invalid or expired form token. Please go back and try again.');
}

app.get('/admin/login', (req, res) => {
  if (req.session.user) return res.redirect('/admin');
  res.send(loginPage({ csrf: ensureCsrf(req) }));
});

app.post('/admin/login', loginLimiter, checkCsrf, (req, res) => {
  const { username, password } = req.body || {};
  const okUser = safeEqual(username || '', process.env.ADMIN_USER || 'admin');
  const okPass = safeEqual(password || '', process.env.ADMIN_PASSWORD || '');
  if (!process.env.ADMIN_PASSWORD) {
    return res.send(loginPage({ csrf: ensureCsrf(req), error: 'Server has no ADMIN_PASSWORD set. Add one to your .env file.' }));
  }
  if (okUser && okPass) {
    req.session.regenerate((err) => {
      if (err) return res.send(loginPage({ csrf: ensureCsrf(req), error: 'Session error. Try again.' }));
      req.session.user = username;
      ensureCsrf(req);
      res.redirect('/admin');
    });
  } else {
    res.status(401).send(loginPage({ csrf: ensureCsrf(req), error: 'Incorrect username or password.' }));
  }
});

app.post('/admin/logout', requireAuth, checkCsrf, (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

app.get('/admin', requireAuth, (req, res) => {
  const query = {
    type: typeof req.query.type === 'string' ? req.query.type : '',
    status: typeof req.query.status === 'string' ? req.query.status : '',
    q: typeof req.query.q === 'string' ? req.query.q : '',
    page: Math.max(Number(req.query.page) || 1, 1),
  };
  const result = db.listSubmissions({ type: query.type, status: query.status, search: query.q, page: query.page });
  res.send(dashboardPage({ stats: db.stats(), result, query, csrf: ensureCsrf(req) }));
});

// Authenticated stats/health for monitoring (moved off the public endpoint).
app.get('/admin/health', requireAuth, (req, res) => {
  res.json({ ok: true, mail: mailer.isConfigured(), stats: db.stats() });
});

app.post('/admin/submissions/:id/status', requireAuth, checkCsrf, (req, res) => {
  const id = Number(req.params.id);
  if (Number.isInteger(id)) {
    try { db.setStatus(id, req.body.status); } catch (_) { /* ignore invalid status */ }
  }
  // Return to the same filtered view the admin was on — same-host /admin paths only.
  let dest = '/admin';
  try {
    const back = req.get('Referer');
    if (back) {
      const u = new URL(back);
      if (u.host === req.headers.host && u.pathname.startsWith('/admin')) dest = u.pathname + u.search;
    }
  } catch (_) { /* malformed referer → default */ }
  res.redirect(dest);
});

// Server-rendered confirmation works under the strict no-script admin CSP.
app.get('/admin/submissions/:id/delete', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const sub = Number.isInteger(id) ? db.getSubmission(id) : null;
  if (!sub) return res.status(404).send('Submission not found.');
  res.send(layout('Confirm deletion', `<main class="wrap"><h1>Delete submission?</h1>
    <p>This permanently deletes the submission from ${esc(sub.name)} and its associated CV.</p>
    <form method="POST" action="/admin/submissions/${id}/delete">
      <input type="hidden" name="_csrf" value="${esc(ensureCsrf(req))}">
      <button class="btn btn-danger" type="submit">Delete permanently</button>
      <a class="btn btn-line" href="/admin">Cancel</a>
    </form></main>`));
});

app.post('/admin/submissions/:id/delete', requireAuth, checkCsrf, (req, res) => {
  const id = Number(req.params.id);
  if (Number.isInteger(id)) {
    const sub = db.getSubmission(id);
    if (sub && sub.cv_filename) {
      // Remove the CV file too, guarding against path traversal.
      const filePath = path.join(UPLOAD_DIR, path.basename(sub.cv_filename));
      if (filePath.startsWith(UPLOAD_DIR)) fs.promises.unlink(filePath).catch(() => {});
    }
    db.deleteSubmission(id);
  }
  res.redirect('/admin');
});

app.get('/admin/submissions/:id/cv', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const sub = Number.isInteger(id) ? db.getSubmission(id) : null;
  if (!sub || !sub.cv_filename) return res.status(404).send('CV not found.');
  const filePath = path.join(UPLOAD_DIR, path.basename(sub.cv_filename)); // basename blocks traversal
  if (!filePath.startsWith(UPLOAD_DIR) || !fs.existsSync(filePath)) return res.status(404).send('CV file missing.');
  try { regularFile(filePath); } catch { return res.status(404).send('CV file missing.'); }
  res.download(filePath, sub.cv_original || sub.cv_filename);
});

// ============================================================
//  STATIC SITE (served last so /api and /admin win)
// ============================================================
app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));

// SPA-style fallback not needed; send index for the bare root only.
app.get('/', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

// 404
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, errors: ['Not found.'] });
  res.status(404).send('<h1 style="font-family:sans-serif;text-align:center;margin-top:20vh">404 — Page not found. <a href="/">Go home</a></h1>');
});

// Error handler — honour parser-provided status (413 too-large, 400 malformed) before 500.
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error('[error]', err.code || err.name || 'SERVER_ERROR');
  if (res.headersSent) return next(err);
  if (req.path.startsWith('/api/')) {
    const msg = status === 413 ? 'Your submission is too large.'
      : status === 400 ? 'Malformed request.'
      : 'Server error.';
    return res.status(status).json({ ok: false, errors: [msg] });
  }
  res.status(status).send(status === 413 ? 'Payload too large.' : 'Server error.');
});

const server = app.listen(PORT, () => {
  console.log(`\n  Madhuban server running →  http://localhost:${PORT}`);
  console.log(`  Admin dashboard        →  http://localhost:${PORT}/admin`);
  console.log(`  Email alerts           →  ${mailer.isConfigured() ? 'ENABLED' : 'disabled (set SMTP_* in .env)'}\n`);
});

// Graceful shutdown: drain connections, checkpoint + close the DB, then exit.
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    console.log(`\n[${sig}] shutting down…`);
    server.close(() => {
      try { db.db.pragma('wal_checkpoint(TRUNCATE)'); db.db.close(); } catch (_) { /* already closed */ }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  });
}

module.exports = app;
