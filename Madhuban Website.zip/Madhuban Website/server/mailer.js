// ============================================================
//  Email notifications — Nodemailer
//  Degrades gracefully: if SMTP is not configured, submissions are
//  still saved; only the email step is skipped (logged, never throws).
// ============================================================
'use strict';

const nodemailer = require('nodemailer');

const TYPE_LABEL = { enquiry: 'Enquiry', contact: 'Contact Message', careers: 'Job Application' };

let transporter = null;
let configured = false;

function init() {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) {
    console.warn('[mailer] SMTP not configured — email alerts disabled (submissions still saved).');
    return;
  }
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT) || 587,
    secure: String(process.env.SMTP_SECURE) === 'true',
    auth: { user: SMTP_USER, pass: SMTP_PASS },
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 20000,
    disableFileAccess: true,
    disableUrlAccess: true,
  });
  configured = true;
  transporter.verify()
    .then(() => console.log('[mailer] SMTP ready — email alerts enabled.'))
    .catch((err) => console.warn('[mailer] SMTP verify failed:', err.code || 'SMTP_ERROR'));
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]
  ));
}

function rows(sub) {
  const lines = [
    ['Name', sub.name],
    ['Email', sub.email],
    ['Phone', sub.phone],
    ['Subject', sub.subject],
  ];
  for (const [k, v] of Object.entries(sub.extra || {})) {
    if (v) lines.push([k.charAt(0).toUpperCase() + k.slice(1), v]);
  }
  if (sub.cv_original) lines.push(['CV', sub.cv_original + ' (see admin dashboard)']);
  lines.push(['Message', sub.message]);
  return lines.filter(([, v]) => v != null && v !== '');
}

// Notify the company team about a new submission.
async function notifyTeam(sub) {
  if (!configured) return { skipped: true };
  const label = TYPE_LABEL[sub.type] || 'Submission';
  const html =
    `<div style="font-family:Arial,sans-serif;max-width:600px">
      <div style="background:#1a1a1a;color:#fff;padding:20px 24px;border-radius:10px 10px 0 0">
        <h2 style="margin:0;font-size:18px">New ${esc(label)} — Madhuban Website</h2>
      </div>
      <table style="width:100%;border-collapse:collapse;border:1px solid #eee;border-top:none">
        ${rows(sub).map(([k, v]) =>
          `<tr>
             <td style="padding:10px 14px;background:#faf7f7;font-weight:bold;width:130px;vertical-align:top;border-bottom:1px solid #eee">${esc(k)}</td>
             <td style="padding:10px 14px;border-bottom:1px solid #eee;white-space:pre-wrap">${esc(v)}</td>
           </tr>`).join('')}
      </table>
      <p style="color:#888;font-size:12px;margin-top:12px">Received ${esc(sub.created_at)} · IP ${esc(sub.ip)}</p>
    </div>`;
  const text = rows(sub).map(([k, v]) => `${k}: ${v}`).join('\n');

  return transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: process.env.NOTIFY_TO || process.env.SMTP_USER,
    replyTo: sub.email || undefined,
    subject: `New ${label}${sub.name ? ' from ' + sub.name : ''}`,
    text,
    html,
  });
}

// Optional acknowledgement to the person who submitted.
async function sendAutoReply(sub) {
  if (!configured) return { skipped: true };
  if (String(process.env.SEND_AUTOREPLY) !== 'true') return { skipped: true };
  if (!sub.email) return { skipped: true };
  const html =
    `<div style="font-family:Arial,sans-serif;max-width:600px;color:#222">
      <p>Dear ${esc(sub.name || 'there')},</p>
      <p>Thank you for reaching out to the <strong>Madhuban Group</strong>. We’ve received your
      ${esc((TYPE_LABEL[sub.type] || 'message').toLowerCase())} and a member of our team will get back to you within one business day.</p>
      <p>Warm regards,<br>Team Madhuban<br>
      <span style="color:#e0413a">Shaping Futures Together</span></p>
    </div>`;
  return transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: sub.email,
    subject: 'We’ve received your message — Madhuban Group',
    text: `Dear ${sub.name || 'there'},\n\nThank you for reaching out to the Madhuban Group. We have received your message and will get back to you within one business day.\n\nWarm regards,\nTeam Madhuban`,
    html,
  });
}

module.exports = { init, notifyTeam, sendAutoReply, isConfigured: () => configured };
