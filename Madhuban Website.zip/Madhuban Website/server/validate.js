// ============================================================
//  Input validation & sanitisation for public form submissions.
// ============================================================
'use strict';

const EMAIL_RE = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
const MAX = { name: 120, email: 160, phone: 40, subject: 160, message: 4000, generic: 200 };

function clean(v, max) {
  if (typeof v !== 'string') return '';
  return String(v).replace(/\0/g, '').trim().slice(0, max || MAX.generic);
}

// Fields we accept per form type. Anything else is ignored.
const SCHEMAS = {
  enquiry: { required: ['name', 'phone', 'email'], extra: ['interest'] },
  contact: { required: ['name', 'phone', 'email', 'message'], extra: [] }, // subject promoted to headline
  careers: { required: ['name', 'phone', 'email'], extra: ['role', 'experience'] },
};

function validate(type, body) {
  const schema = SCHEMAS[type];
  if (!schema) return { ok: false, errors: ['Unknown form type.'] };

  // Honeypot: real users never fill the hidden "website" field.
  if (clean(body.website)) return { ok: false, spam: true, errors: ['Rejected.'] };

  const errors = [];
  const name = clean(body.name, MAX.name);
  const email = clean(body.email, MAX.email);
  const phone = clean(body.phone, MAX.phone);
  const message = clean(body.message, MAX.message);

  if (schema.required.includes('name') && name.length < 2) errors.push('Please enter your name.');
  if (schema.required.includes('email') || email) {
    if (!EMAIL_RE.test(email)) errors.push('Please enter a valid email address.');
  }
  if (schema.required.includes('phone') && phone.length < 6) errors.push('Please enter a valid phone number.');
  if (schema.required.includes('message') && message.length < 1) errors.push('Please enter a message.');

  // Collect type-specific extras (rendered as chips), then promote ONE to the
  // headline "subject" line and remove it from extra so it isn't displayed twice.
  const extra = {};
  for (const key of schema.extra) {
    const val = clean(body[key], MAX.generic);
    if (val) extra[key] = val;
  }
  let subject = clean(body.subject, MAX.subject);
  if (!subject && extra.interest) { subject = extra.interest; delete extra.interest; }
  if (!subject && extra.role) { subject = extra.role; delete extra.role; }

  return {
    ok: errors.length === 0,
    errors,
    data: { type, name, email, phone, subject, message, extra },
  };
}

module.exports = { validate, clean, EMAIL_RE };
