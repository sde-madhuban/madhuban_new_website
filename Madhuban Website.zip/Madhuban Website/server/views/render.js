// ============================================================
//  Server-rendered admin views (no external dependencies).
//  Every dynamic value passes through esc() to prevent stored XSS.
// ============================================================
'use strict';

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

const BASE_CSS = `
  *{box-sizing:border-box}
  body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f5f5f6;color:#1f2937}
  a{color:#e0413a}
  .wrap{max-width:1180px;margin:0 auto;padding:0 20px}
  .topbar{background:#1a1a1a;color:#fff;padding:14px 0}
  .topbar .wrap{display:flex;align-items:center;justify-content:space-between}
  .brand{display:flex;align-items:center;gap:10px;font-weight:700;letter-spacing:.04em}
  .peak{width:26px;height:26px}
  .btn{display:inline-flex;align-items:center;gap:6px;border:0;border-radius:8px;padding:8px 14px;font-weight:600;font-size:.86rem;cursor:pointer;text-decoration:none;transition:.15s}
  .btn-red{background:#e0413a;color:#fff}.btn-red:hover{background:#b8322c}
  .btn-ghost{background:#2a2a2a;color:#fff}.btn-ghost:hover{background:#3a3a3a}
  .btn-sm{padding:5px 10px;font-size:.78rem}
  .btn-line{background:#fff;border:1px solid #d8d8d8;color:#333}.btn-line:hover{border-color:#e0413a;color:#e0413a}
  .btn-danger{background:#fff;border:1px solid #f0c8c6;color:#c0392b}.btn-danger:hover{background:#c0392b;color:#fff}
  .stats{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:24px 0}
  .stat{background:#fff;border:1px solid #eee;border-radius:12px;padding:16px 18px}
  .stat b{display:block;font-size:1.8rem;color:#1a1a1a;line-height:1}
  .stat span{font-size:.8rem;color:#6b7280}
  .stat.hot b{color:#e0413a}
  .toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:16px}
  .tabs{display:flex;gap:6px;flex-wrap:wrap}
  .tab{padding:7px 14px;border-radius:99px;background:#fff;border:1px solid #e2e2e2;color:#444;text-decoration:none;font-size:.85rem;font-weight:600}
  .tab.active{background:#1a1a1a;color:#fff;border-color:#1a1a1a}
  .search{margin-left:auto;display:flex;gap:8px}
  .search input,.search select{padding:8px 12px;border:1px solid #d8d8d8;border-radius:8px;font-size:.86rem}
  .card{background:#fff;border:1px solid #eee;border-radius:12px;padding:16px 18px;margin-bottom:12px}
  .card.new{border-left:4px solid #e0413a}
  .card-head{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between}
  .who{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .badge{font-size:.68rem;text-transform:uppercase;letter-spacing:.06em;font-weight:700;padding:3px 9px;border-radius:99px}
  .b-enquiry{background:#e8f0fe;color:#1a56db}.b-contact{background:#fdecea;color:#c0392b}.b-careers{background:#e7f6ec;color:#1e874b}
  .pill-new{background:#e0413a;color:#fff;font-size:.66rem;padding:2px 8px;border-radius:99px;font-weight:700}
  .pill-handled{background:#e6e6e6;color:#555;font-size:.66rem;padding:2px 8px;border-radius:99px;font-weight:700}
  .name{font-weight:700;font-size:1.02rem}
  .meta{color:#6b7280;font-size:.82rem;margin-top:6px;display:flex;flex-wrap:wrap;gap:14px}
  .meta a{color:#374151;text-decoration:none}.meta a:hover{color:#e0413a}
  .subject{margin-top:8px;font-weight:600;color:#374151}
  .msg{margin-top:6px;color:#4b5563;white-space:pre-wrap;font-size:.92rem;line-height:1.5}
  .kv{margin-top:8px;display:flex;flex-wrap:wrap;gap:8px}
  .kv span{background:#f3f4f6;border-radius:6px;padding:3px 9px;font-size:.78rem;color:#374151}
  .actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
  .empty{background:#fff;border:1px dashed #ddd;border-radius:12px;padding:48px;text-align:center;color:#9ca3af}
  form.inline{display:inline}
  @media(max-width:760px){.stats{grid-template-columns:repeat(2,1fr)}.search{margin-left:0;width:100%}}
`;

const PEAK = '<svg class="peak" viewBox="0 0 48 48"><path d="M24 5 44 40H26.5L24 30 21.5 40H4L24 5Z" fill="#e0413a"/><path d="M24 5 33 40h-6.5L24 30 21.5 40H15L24 5Z" fill="#fff"/></svg>';

function layout(title, body) {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>${esc(title)} · Madhuban Admin</title><style>${BASE_CSS}</style></head><body>${body}</body></html>`;
}

function loginPage({ error, csrf } = {}) {
  return layout('Login', `
    <div style="min-height:100vh;display:grid;place-items:center;background:#1a1a1a">
      <form method="POST" action="/admin/login" style="background:#fff;padding:34px 30px;border-radius:16px;width:340px;max-width:92vw;box-shadow:0 30px 60px -30px rgba(0,0,0,.6)">
        <input type="hidden" name="_csrf" value="${esc(csrf)}">
        <div class="brand" style="color:#1a1a1a;justify-content:center;margin-bottom:6px">${PEAK}<span>MADHUBAN</span></div>
        <p style="text-align:center;color:#6b7280;font-size:.85rem;margin:0 0 20px">Admin Dashboard</p>
        ${error ? `<p style="background:#fdecea;color:#c0392b;padding:10px;border-radius:8px;font-size:.85rem;margin:0 0 14px">${esc(error)}</p>` : ''}
        <label for="username" style="font-size:.8rem;font-weight:600">Username</label>
        <input id="username" name="username" autocomplete="username" required style="width:100%;padding:10px 12px;border:1px solid #d8d8d8;border-radius:8px;margin:6px 0 14px">
        <label for="password" style="font-size:.8rem;font-weight:600">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required style="width:100%;padding:10px 12px;border:1px solid #d8d8d8;border-radius:8px;margin:6px 0 20px">
        <button class="btn btn-red" style="width:100%;justify-content:center">Sign In</button>
      </form>
    </div>`);
}

function statCards(s) {
  const cell = (n, label, hot) => `<div class="stat${hot ? ' hot' : ''}"><b>${n}</b><span>${esc(label)}</span></div>`;
  return `<div class="stats">
    ${cell(s.total, 'Total')}
    ${cell(s.new, 'New / Unread', true)}
    ${cell(s.enquiry, 'Enquiries')}
    ${cell(s.contact, 'Contact')}
    ${cell(s.careers, 'Applications')}
  </div>`;
}

function tab(label, key, cur, q) {
  const params = new URLSearchParams();
  if (key) params.set('type', key);
  if (q.status) params.set('status', q.status);
  if (q.q) params.set('q', q.q);
  const href = '/admin' + (params.toString() ? '?' + params.toString() : '');
  const active = (cur || '') === (key || '');
  return `<a class="tab${active ? ' active' : ''}" href="${esc(href)}">${esc(label)}</a>`;
}

function submissionCard(sub, csrf) {
  const TYPE = { enquiry: 'Enquiry', contact: 'Contact', careers: 'Application' };
  const contactBits = [];
  if (sub.email) contactBits.push(`<a href="mailto:${esc(sub.email)}">✉ ${esc(sub.email)}</a>`);
  if (sub.phone) contactBits.push(`<a href="tel:${esc(sub.phone)}">✆ ${esc(sub.phone)}</a>`);
  contactBits.push(`🕑 ${esc(sub.created_at)} UTC`);

  const extras = Object.entries(sub.extra || {})
    .map(([k, v]) => `<span><b>${esc(k)}:</b> ${esc(v)}</span>`).join('');

  const cvBtn = sub.cv_filename
    ? `<a class="btn btn-line btn-sm" href="/admin/submissions/${sub.id}/cv">⬇ CV${sub.cv_original ? ' (' + esc(sub.cv_original) + ')' : ''}</a>`
    : '';

  const toggle = sub.status === 'new' ? 'handled' : 'new';
  const toggleLabel = sub.status === 'new' ? 'Mark handled' : 'Mark new';

  return `<div class="card ${sub.status === 'new' ? 'new' : ''}">
    <div class="card-head">
      <div class="who">
        <span class="badge b-${esc(sub.type)}">${esc(TYPE[sub.type] || sub.type)}</span>
        <span class="name">${esc(sub.name)}</span>
        <span class="${sub.status === 'new' ? 'pill-new' : 'pill-handled'}">${sub.status === 'new' ? 'NEW' : 'HANDLED'}</span>
      </div>
      <span style="color:#9ca3af;font-size:.8rem">#${sub.id}</span>
    </div>
    <div class="meta">${contactBits.join('')}</div>
    ${sub.subject ? `<div class="subject">${esc(sub.subject)}</div>` : ''}
    ${extras ? `<div class="kv">${extras}</div>` : ''}
    ${sub.message ? `<div class="msg">${esc(sub.message)}</div>` : ''}
    <div class="actions">
      <form class="inline" method="POST" action="/admin/submissions/${sub.id}/status">
        <input type="hidden" name="_csrf" value="${esc(csrf)}">
        <input type="hidden" name="status" value="${toggle}">
        <button class="btn btn-line btn-sm" type="submit">${toggleLabel}</button>
      </form>
      ${cvBtn}
      <a class="btn btn-danger btn-sm" href="/admin/submissions/${sub.id}/delete">Delete</a>
    </div>
  </div>`;
}

function buildQuery(params) {
  const sp = new URLSearchParams();
  if (params.type) sp.set('type', params.type);
  if (params.status) sp.set('status', params.status);
  if (params.q) sp.set('q', params.q);
  if (params.page && params.page > 1) sp.set('page', params.page);
  const s = sp.toString();
  return '/admin' + (s ? '?' + s : '');
}

function dashboardPage({ stats, result, query, csrf }) {
  const items = result.items;
  const q = { status: query.status || '', q: query.q || '' };
  const cur = query.type || '';
  const list = items.length
    ? items.map((s) => submissionCard(s, csrf)).join('')
    : `<div class="empty">No submissions found for this view.</div>`;

  const base = { type: cur, status: q.status, q: q.q };
  const pager = result.pages > 1 ? `
      <div style="display:flex;align-items:center;justify-content:center;gap:16px;margin:8px 0 40px">
        ${result.page > 1 ? `<a class="btn btn-line btn-sm" href="${esc(buildQuery(Object.assign({}, base, { page: result.page - 1 })))}">← Prev</a>` : '<span style="width:70px"></span>'}
        <span style="font-size:.85rem;color:#6b7280">Page ${result.page} of ${result.pages}</span>
        ${result.page < result.pages ? `<a class="btn btn-line btn-sm" href="${esc(buildQuery(Object.assign({}, base, { page: result.page + 1 })))}">Next →</a>` : '<span style="width:70px"></span>'}
      </div>` : '';
  const countLine = `<p style="color:#9ca3af;font-size:.78rem;margin:22px 0 ${result.pages > 1 ? '8px' : '40px'};text-align:center">${result.total} record(s) total${result.pages > 1 ? ` · showing ${items.length} on this page` : ''}.</p>`;

  return layout('Dashboard', `
    <div class="topbar"><div class="wrap">
      <div class="brand">${PEAK}<span>MADHUBAN · Admin</span></div>
      <div style="display:flex;gap:10px;align-items:center">
        <a class="btn btn-ghost btn-sm" href="/" target="_blank">View site ↗</a>
        <form class="inline" method="POST" action="/admin/logout"><input type="hidden" name="_csrf" value="${esc(csrf)}"><button class="btn btn-red btn-sm">Log out</button></form>
      </div>
    </div></div>
    <div class="wrap">
      ${statCards(stats)}
      <div class="toolbar">
        <div class="tabs">
          ${tab('All', '', cur, q)}
          ${tab('Enquiries', 'enquiry', cur, q)}
          ${tab('Contact', 'contact', cur, q)}
          ${tab('Applications', 'careers', cur, q)}
        </div>
        <form class="search" method="GET" action="/admin">
          ${cur ? `<input type="hidden" name="type" value="${esc(cur)}">` : ''}
          <select name="status">
            <option value=""${q.status === '' ? ' selected' : ''}>All status</option>
            <option value="new"${q.status === 'new' ? ' selected' : ''}>New</option>
            <option value="handled"${q.status === 'handled' ? ' selected' : ''}>Handled</option>
          </select>
          <input name="q" value="${esc(q.q)}" placeholder="Search name, email, message…">
          <button class="btn btn-red btn-sm" type="submit">Search</button>
        </form>
      </div>
      ${list}
      ${countLine}
      ${pager}
    </div>`);
}

module.exports = { esc, layout, loginPage, dashboardPage };
