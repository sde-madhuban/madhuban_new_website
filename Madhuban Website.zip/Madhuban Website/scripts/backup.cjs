'use strict';
// Offline maintenance only: callers must stop every writer before backup/restore.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Database = require('better-sqlite3');
const {privateDirectory, regularFile, inside, resolved} = require('../server/storage');
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(regularFile(file))).digest('hex');
function validateDatabase(file) {
  const db = new Database(regularFile(file), {readonly: true, fileMustExist: true});
  try {
    if (db.pragma('integrity_check', {simple: true}) !== 'ok') throw new Error('Database integrity check failed');
    const names = db.prepare('SELECT DISTINCT cv_filename FROM submissions WHERE cv_filename IS NOT NULL').all().map(r => r.cv_filename);
    for (const name of names) if (!name || path.basename(name) !== name || /[\\/]/.test(name) || name === '..') throw new Error('Unsafe document reference');
    return names;
  } finally { db.close(); }
}
function copyFile(source, destination) {
  fs.copyFileSync(regularFile(source), destination, fs.constants.COPYFILE_EXCL);
  fs.chmodSync(destination, 0o600);
}
function verify(snapshot) {
  const manifest = JSON.parse(fs.readFileSync(regularFile(path.join(snapshot, 'manifest.json')), 'utf8'));
  if (manifest.version !== 1 || !Array.isArray(manifest.files)) throw new Error('Unsupported backup manifest');
  const expected = ['madhuban.db', ...validateDatabase(path.join(snapshot, 'madhuban.db')).map(n => 'uploads/' + n)].sort();
  const actual = manifest.files.map(f => f.path).sort();
  if (JSON.stringify(expected) !== JSON.stringify(actual)) throw new Error('Backup manifest does not match database');
  for (const file of manifest.files) {
    if (hash(path.join(snapshot, file.path)) !== file.sha256) throw new Error('Backup checksum mismatch');
  }
  return expected;
}
async function main(args) {
  const [action, sourceArg, destArg, flag] = args;
  if (!['create','verify','restore'].includes(action) || !sourceArg || (action !== 'verify' && (!destArg || flag !== '--offline'))) {
    throw new Error('Usage: backup.cjs create DATA_DIR NEW_SNAPSHOT --offline | verify SNAPSHOT | restore SNAPSHOT NEW_RESTORE_DIR --offline. Stop all application writers first.');
  }
  const source = resolved(sourceArg);
  if (action === 'verify') { verify(source); return; }
  const dest = resolved(destArg);
  const uploads = resolved(process.env.UPLOAD_DIR || path.join(__dirname, '..', 'server', 'uploads'));
  if (fs.existsSync(dest) || inside(source,dest) || inside(dest,source) || (action === 'create' && (inside(uploads,dest) || inside(dest,uploads)))) throw new Error('Destination must be a new, separate directory');
  if (action === 'restore') verify(source);
  privateDirectory(dest);
  try {
    fs.mkdirSync(path.join(dest,'uploads'), {mode:0o700});
    if (action === 'create') {
      const sourceDB = path.join(source, 'madhuban.db');
      regularFile(sourceDB);
      const db = new Database(sourceDB, {readonly:true, fileMustExist:true});
      try { await db.backup(path.join(dest,'madhuban.db')); } finally { db.close(); }
      fs.chmodSync(path.join(dest,'madhuban.db'),0o600);
      // Sessions must not be restored: force fresh authentication after recovery.
      const clean = new Database(path.join(dest,'madhuban.db'));
      try { clean.exec('DROP TABLE IF EXISTS sessions'); clean.pragma('journal_mode = DELETE'); clean.exec('VACUUM'); } finally { clean.close(); }
      const files = ['madhuban.db'];
      for (const name of validateDatabase(path.join(dest,'madhuban.db'))) {
        copyFile(path.join(uploads,name),path.join(dest,'uploads',name));
        files.push('uploads/'+name);
      }
      fs.writeFileSync(path.join(dest,'manifest.json'), JSON.stringify({version:1,createdAt:new Date().toISOString(),files:files.map(file=>({path:file,sha256:hash(path.join(dest,file))}))},null,2)+'\n',{mode:0o600,flag:'wx'});
      verify(dest);
    } else {
      for (const file of verify(source)) copyFile(path.join(source,file),path.join(dest,file));
      validateDatabase(path.join(dest,'madhuban.db'));
    }
  } catch (err) { fs.rmSync(dest,{recursive:true,force:true}); throw err; }
}
if (require.main === module) main(process.argv.slice(2)).then(()=>console.log('Backup operation completed.')).catch(()=>{console.error('Backup operation failed. Check arguments, offline state, private paths, database integrity and document checksums. No existing destination is overwritten.');process.exitCode=1;});
module.exports = {main,verify};
