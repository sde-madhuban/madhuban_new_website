'use strict';
// Run only after the approved canonical origin and publication readiness are confirmed.
// This prepares files; it does not configure DNS, TLS, redirects or hosting.
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..', 'public');
const raw = process.env.PUBLIC_SITE_URL;
if (!raw || process.env.PUBLICATION_APPROVED !== 'true') {
  console.error('PUBLIC_SITE_URL and PUBLICATION_APPROVED=true are required after company/legal/content approval. No files changed.');
  process.exit(1);
}
let origin;
try {
  const url = new URL(raw);
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.pathname !== '/' || url.search || url.hash || !url.hostname.includes('.') || /(^|\.)(localhost|example\.(com|org|net)|invalid|test)$/.test(url.hostname)) throw new Error();
  origin = url.origin;
} catch {
  console.error('Use the approved public HTTPS origin, without a path, credentials, query or fragment. No files changed.');
  process.exit(1);
}
const escape = value => value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const pages = fs.readdirSync(root).filter(file => file.endsWith('.html'));
const sitemap = [];
for (const file of pages) {
  const dest = path.join(root, file);
  let source = fs.readFileSync(dest, 'utf8');
  const legal = ['privacy-policy.html', 'terms-and-conditions.html'].includes(file);
  const route = file === 'index.html' ? '/' : legal ? '/' + file.replace('.html', '') : '/' + file;
  const url = escape(origin + route);
  source = source.replace(/\s*<link rel="canonical"[^>]*>/g, '').replace(/\s*<meta property="og:url"[^>]*>/g, '');
  source = source.replace(/<meta property="og:image" content="[^"]*">/, '<meta property="og:image" content="' + escape(origin) + '/images/social-preview.png">');
  source = source.replace('</head>', '  <link rel="canonical" href="' + url + '">\n  <meta property="og:url" content="' + url + '">\n</head>');
  fs.writeFileSync(dest, source);
  // Draft legal notices stay out of the sitemap until their noindex is explicitly removed after review.
  if (!/<meta name="robots" content="[^"]*noindex/.test(source)) sitemap.push('  <url><loc>' + url + '</loc></url>');
}
fs.writeFileSync(path.join(root, 'sitemap.xml'), '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + sitemap.join('\n') + '\n</urlset>\n');
fs.writeFileSync(path.join(root, 'robots.txt'), 'User-agent: *\nDisallow: /admin\nDisallow: /api/\nSitemap: ' + origin + '/sitemap.xml\n');
console.log('Canonical metadata, absolute social image URLs, sitemap and robots prepared. DNS, TLS, redirects and live forms still require verification.');
