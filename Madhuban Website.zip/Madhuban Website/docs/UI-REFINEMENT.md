# Corporate UI refinement

## Audit (before implementation)

The frontend comprises 12 static HTML pages, a shared stylesheet, shared header/footer/dialog renderer, and page interaction JavaScript. Tailwind CDN utilities coexist with extensive inline styles. Express serves the existing enquiry, contact, and CV upload endpoints. No frontend build or lint script exists; npm test runs backend module smoke checks.

Existing typography uses Google Fonts Inter and Poppins; icons are inline SVG. Logo and leadership portraits are local; architectural imagery uses existing Unsplash URLs. The shared components are reusable and were retained. The stylesheet contained two overlapping palette definitions, charcoal rather than navy foundations, inconsistent radii, strong hover movement, and mixed heading sizes. Dialogs lacked focus containment and return, the closed mobile drawer remained keyboard reachable, form labels were unassociated or absent, and several composed cards had duplicate class attributes that prevented mobile collapse.

## Implementation

- Centralised navy, deep navy, crimson/hover, gold, ivory, white, graphite, muted text and border tokens. Added semantic surface, on-dark, accessible light-crimson accent, focus and brand-soft tokens.
- Added 4/8px spacing increments, 1320px maximum content width, responsive gutters/section spacing, 4/8/12px radii, restrained shadow and heading scale.
- Selected Manrope for editorial headings and retained Inter body text through the existing Google Fonts provider (both open-source families). Existing client wordmark treatments are retained.
- Refined white navigation, crimson CTAs, navy hero overlays, stable 44px slide controls, navy footer, cards and forms. Preserved photography, logo, business copy and destinations.
- Added skip links and main landmarks, associated form labels, phone/autofill semantics, live inline errors, dialog focus containment/return, inert background and hidden drawer, active navigation semantics, Escape dismissal for dropdowns, mobile search access, and lazy image loading.
- Preserved reduced-motion support and removed decorative WhatsApp pulsing. Existing page interactions and form payloads/endpoints remain intact.

## Modified files

`public/css/styles.css`, `public/js/components.js`, and all 12 HTML files: `index`, `about`, `commercial`, `industrial`, `hospitality`, `residential`, `upcoming`, `clients`, `awards`, `csr`, `careers`, `contact`. This document records scope and validation. No backend, dependencies, routes, or deployment configuration changes.

## Validation

Chrome headless checked all 12 pages at 320, 360, 390, 430, 768, 1024, 1440 and 1920px (96 layouts): no document horizontal overflow or JavaScript exceptions. Desktop/mobile homepage and mobile contact/upcoming screenshots were visually inspected. Search, carousel slide selection, mobile drawer, dialog focus containment and Escape, location switching, and mocked contact error rendering passed. Mocked enquiry success from the mobile drawer, careers multipart submission, normal-motion carousel pause, and keyboard dropdown open/Escape also passed. JavaScript syntax checks and existing npm test passed. There are no configured lint or build commands. These checks are targeted QA, not a full WCAG conformance audit.

## Existing limitations

Remote fonts, Tailwind CDN, map and photography still depend on third-party availability. Existing social links point to #; no destinations were invented. Historical year/statistic copy and illustrative project photography were preserved per brief. Real form delivery/database writes are outside visual QA; browser form responses are mocked to avoid creating leads or applications.
