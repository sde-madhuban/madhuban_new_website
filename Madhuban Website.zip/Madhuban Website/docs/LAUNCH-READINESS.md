# Madhuban website — engineering and launch review

Status: NOT approved for production launch. This is the first-stage historical record. The current second-stage status is in [LAUNCH-READINESS-REGISTER.md](LAUNCH-READINESS-REGISTER.md), with separate [visual](VISUAL-QUALITY-REVIEW.md) and [security](PRODUCTION-SECURITY-REVIEW.md) reports. The runtime Tailwind CDN has since been removed and backend/dependency hardening has been implemented; first-stage statements below describe that earlier snapshot.

## Changes

- Added `/privacy-policy` and `/terms-and-conditions` as explicitly labelled, noindex drafts. Existing Express `extensions: ['html']` serves these routes without new backend routing. Footer and form privacy links are included.
- Added ICO (16/32/48), PNG (32/192), Apple touch icon (180) and 1200×630 social image derived from the complete existing logo on approved navy. No generated imagery or altered logo geometry.
- Added brand/social metadata to all pages. Canonical origin is deliberately unset pending approval.
- Removed residual public pill radii, blur and emoji decoration. Withheld the generic YouTube film and `#` social destinations; original fragments remain in `docs/review/` for restoration with approved links. Working navigation and APIs are preserved.
- Removed fake file:// form success. An unavailable server now reports that data was not sent and preserves the input.
- Added pre-launch robots restrictions and an opt-in SEO preparation script. No domain was inferred from email addresses, no deployment performed.
- No AI builder attribution was found. Existing HorseTech attribution is retained because contractual status is unknown.

## Verified source-level data flows

| Feature | Source evidence | Confirmation needed |
| --- | --- | --- |
| Enquiry/contact | `public/js/components.js`, `server/validate.js`: name, phone, email, message, interest/subject | Approved purposes, notice and handling procedures |
| Careers/CV | Same modules plus `server/server.js`: role, experience, optional PDF/DOC/DOCX, 5 MB limit | Recruitment retention and authorised recipients |
| Records | `server/db.js`: SQLite; IP, user agent, receipt time, submission fields | Host, location, access ownership, backup policy |
| Email | `server/mailer.js`: configurable SMTP, team notification, optional auto-reply | Actual provider, recipients, production delivery |
| Sessions | `server/server.js`: admin cookie `madhuban.sid`, HTTP-only, SameSite lax, eight-hour lifetime, uninitialised sessions not saved | Production HTTPS/proxy/cookie configuration |
| Logs | Morgan access logs; operational error output | Hosting log collection and retention |
| External requests | Google Fonts, Tailwind CDN, Unsplash, Google Maps, WhatsApp outbound link | Licences, providers, privacy/consent review |
| Analytics | None found in repository | Confirm host, CDN and tag injection separately |
| Deletion | Admin delete removes database record and associated CV; no automatic schedule found | Approved periods and email/backup deletion |

Legal drafts intentionally do not invent an operating entity, registered address, retention promises, jurisdiction, liability exclusions, statutory compliance claims or effective date. Legal review should consult the current [MeitY DPDP rules and enforcement materials](https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa). The technical draft is not legal approval.

## Content and rights approval — launch blockers

Existing content is preserved in this local working copy, not certified as approved and not newly deployed. No supporting company approval records were available. Do not publish until the following have been approved or withheld from the release:

- Company history (1997), legacy figures (27+ years), client count (50+), project count (7), business division count, development areas and project specifications.
- All named clients and text wordmarks, awards and recognition details, leadership titles, CSR activity claims and future project classifications (including “5-star”).
- Existing contact details, office locations, WhatsApp availability and one-business-day response promise.
- Local leadership photos: confirm rights and identities; existing files are not proof of a licence.
- Unsplash images: `docs/review/image-register.json` records each URL and page. These are stock images, not verified Madhuban project photos. Some existing alt text/captions associate them with named projects; approved authentic replacements or explicit illustrative captions are required before publication. Do not silently treat these as genuine project evidence.
- Official social profiles and a specific approved brand-film URL are missing; their nonfunctional placeholders are withheld.

## Domain and SEO handoff

1. Obtain the approved canonical HTTPS domain and hosting/DNS access. Confirm ownership using the registrar/DNS account; an email domain is not proof.
2. Configure DNS, certificate, HTTP→HTTPS and chosen www/non-www redirects at the hosting/proxy layer. Do not redirect POST bodies through an untested hostname change.
3. Complete legal, content and asset review. Finalise legal drafts, remove their draft status and noindex only after authorised acceptance.
4. Run `PUBLIC_SITE_URL=https://<approved-domain> PUBLICATION_APPROVED=true node scripts/prepare-seo.js` using the actual approved origin. It generates canonical/OG URLs, sitemap and robots; it does not prove ownership, TLS or approval. Legal pages remain excluded while marked noindex.
5. Verify canonical URLs, sitemap, robots, social image fetches, redirect chains, TLS, every internal route and actual form delivery on that origin. Confirm intentional indexing; pre-launch robots currently disallows all crawling. Robots is not access control—use private staging access where needed.
6. Complete a real production submission/delivery check with authorised test data and cleanup. Verify persistent storage, CV retrieval and admin access. Local checks do not establish live delivery.

There is no frontend compilation/build, lint or type-check command in this repository. It is an Express/static site; no build tooling was invented. Existing Tailwind runtime CDN remains a production dependency to evaluate before launch.

## Validation results

- `npm test`: passed existing module smoke checks.
- `node tests/engineering.cjs`: passed production-mode startup with temporary database/uploads and SMTP disabled, all 14 HTML pages, extensionless legal routes, favicon/social/robots responses, all three form APIs (invalid and valid), persisted record count, CV storage/rejection, and unauthenticated admin/CV protection. Temporary data is removed by the test.
- Chrome: 14 pages × 8 viewport widths (320, 360, 390, 430, 768, 1024, 1440, 1920): no document horizontal overflow or page JavaScript errors.
- Browser link/image pass: 30 unique internal destinations returned success; no dead `#` anchors, image decode failures or recorded network failures in that run. This verifies requested assets, not their licence or authenticity. WhatsApp is the only remaining external anchor; destination account ownership remains unverified.
- Interactive browser checks: search, mobile drawer, enquiry focus trap/Escape, manual carousel selection, mocked contact error response and location switch passed. The focus-trap test was updated to account for the newly added privacy link as the last focusable element.
- The initial visual review caught an extra footer closing tag after social-placeholder removal; it was fixed and the affected browser checks repeated.
- SEO script syntax and missing-approval guard verified. No real canonical domain was configured. No production DNS/HTTPS/live email checks were possible without an approved origin and access.
- Privacy page inspected in mobile and desktop Chrome. Legal pages remain labelled drafts and noindex. These targeted checks are not a full accessibility certification.

Additional completed checks: mocked careers multipart/enquiry success, carousel pause, keyboard dropdown/Escape, project-slider arrow, logo-animation pause and corrected footer DOM passed. Core text contrast ratios: body/white 13.95:1, muted/ivory 4.53:1, white/crimson CTA 5.71:1, footer/deep navy 12.15:1, legal links/white 7.77:1. These do not establish contrast over every photograph. Favicon and corrected footer were visually inspected. Repeat the isolated API suite with `npm run test:engineering`.

Modified/new files in this pass: all 12 existing public HTML pages; `public/privacy-policy.html`, `public/terms-and-conditions.html`, `public/css/styles.css`, `public/js/components.js`, favicon/Apple/social image assets, `public/robots.txt`, `scripts/prepare-seo.js`, `tests/engineering.cjs`, `package.json`, this report and `docs/review/*`. No backend implementation or dependency changes.
