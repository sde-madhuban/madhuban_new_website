# Visual quality review

Review completed locally, 5 November 2026 (Asia/Kolkata). Production remains unapproved.

## Scope and evidence

Reviewed actual Chrome renders of all 14 pages at 390px mobile, 768px tablet and 1440px desktop: 42 full-page captures before changes and 42 after. Initial contact sheets were visually inspected for every page/resolution; affected final sheets were inspected again. Final sheets are in `review/stage2/` (`390-sheet-*`, `768-sheet-*`, `desktop-sheet-*`). Additional automated layout checks covered all eight requested widths, 320–1920px: 112 layouts, no document overflow or page JavaScript errors. Automated layout success is not a subjective design approval.

## Overall judgement

Navigation, navy/ivory surfaces and restrained crimson buttons form a credible corporate foundation. The logo proportions and established hero headline are retained. No new stock or synthetic imagery, slogans, testimonials or gold decoration were introduced. The site is **not yet an authentic finished corporate presentation**: the stock photographs, unsubstantiated statistics, repeated promotional copy and missing evidence of projects/awards are the principal remaining problems. Cosmetic changes cannot resolve those deficiencies.

## Page-by-page findings

| Page | Rendered observation at mobile/tablet/desktop | Local improvement | Remaining concern |
| --- | --- | --- | --- |
| Home | Clear hero and CTA hierarchy; mobile floating chat obscured content; statistics counted up; gallery lacked keyboard focus | Static authored numbers, immediate content, focusable gallery, mobile chat moved to footer, stronger mobile photo overlay | Generic architectural images and copy do not establish Madhuban project identity; original headline preserved; all claims pending |
| About | Editorial sections align; five value cards create an uneven final row on narrow screens; crimson founder text failed contrast | Accessible light accent on founder navy panel; reduced scroll effects | Initials-only portrait, attributed quotations, leadership roles/history and stock value images require approval |
| Commercial | Tall portrait photo dominated tablet and mobile; CTA clear | Image bounded to 460px with 4:3 crop below 900px | Stock office picture, Grade A and operating claims require evidence |
| Industrial | Clear feature/metrics hierarchy; warehouse image dominates desktop | Shared motion and mobile chat corrections | Named project picture, 1,65,000 sq ft, TATA relationship and infrastructure specifications unverified |
| Hospitality | Balanced photo/story and business categories | Shared base/interaction refinements | Restaurant stock photo is not evidence of the named restaurant; history and upcoming classification pending |
| Residential | Two readable editorial stories; image follows copy in second mobile section | Existing ordering retained; no gratuitous redesign | Luxury stock houses may misrepresent named apartment projects; project facts and locations pending |
| Upcoming | Consistent two-project layout, mobile cards quite long | Existing labels and rectangular controls retained | 5-star classification, locations, timing and illustrative resort/restaurant images pending |
| Clients | Uniform wordmark grid, strong whitespace; narrow tablet metric cards are visually sparse | CSS hover replaces inline scripting | Text treatments are not approved client logo assets; relationships and counts need evidence |
| Awards | Single feature is legible; restrained award accent | No additional gold effects | “Best IT Park” lacks awarding organisation/date/certificate; stock photo not verification |
| CSR | Content cards readable; tree-plantation card actually shows solar panels; crimson-on-navy metrics failed contrast | Metric text contrast fixed | Mismatched existing photo and activity claims are release blockers; no invented replacement supplied |
| Careers | Clear application form; upload format/size was unstated; floating chat interfered on mobile | File-format/5 MB help, accept hint, styled native chooser, persistent feedback and non-obscuring chat | HR details, response promise and recruitment claims pending; no invented openings |
| Contact | Labels and location selector clear; lazy map appears blank in full-page captures | Location selected-state semantics, persistent feedback, same-location external map fallback | Embedded-map operation/accuracy not certified; office-specific destination needs company evidence |
| Privacy | Readable editorial layout with clear draft notice | Explicit heading/list/paragraph styling with local base; external-service inventory updated after CDN removal | Legal/entity/provider/retention approval missing; remains noindex |
| Terms | Consistent readable draft layout | Same base/document styles | Not legally adopted; entity, jurisdiction and approved final wording missing |

## Changes made

- Removed the Tailwind runtime CDN and replaced the base styles used by the existing authored CSS with `public/css/base.css`; no replacement framework or runtime dependency.
- Retained section structure and brand assets. Reduced repeated reveal, hero-entry and count-up animation. Carousel and user-controlled logo animation remain keyboard-operable and respect reduced motion.
- Fixed confirmed contrast failures on founder and CSR navy panels. Darkened only the mobile hero photo overlay so copy is less dependent on the photograph's brightness.
- Kept WhatsApp available in the footer on all sizes; hid its overlapping floating duplicate at widths up to 900px.
- Added keyboard access to the project scroller, persistent successful form feedback, explicit failure on malformed/HTML “success” responses, file guidance and map fallback.
- Removed inline client/search hover handlers in favour of CSS to support a strict script CSP.

## Accessibility checks and limits

Axe-core WCAG 2 A/AA, 2.1 AA and 2.2 AA tagged rules ran on all 14 pages at 390px. Before: colour-contrast violations on About/CSR and scrollable-region-focusable on Home. After: zero **automatically detected violations** for that rule set. Raw results: `review/stage2/axe-before.json` and `axe-after.json`. Axe injection used a separate CSP-bypassed test context solely to load the audit tool; functional Chrome tests used normal CSP.

Keyboard tests exercised mobile drawer, search, dialog focus trapping/return and Escape, expertise dropdown/Escape, gallery controls, location buttons and carousel controls. Reduced-motion preference stops automatic carousel/animation. Heading structure and accessible form/control names were reviewed. Persistent status messages now survive the short toast. The existing skip link and focus rings remain.

Axe lists incomplete contrast checks over imagery; those are not passes. Rendered imagery was visually reviewed, and the mobile hero overlay strengthened, but every pixel/crop/slide has not been measured. Screen-reader testing, real iOS/Android/Safari/Firefox, OS high-contrast mode, full 400% zoom/reflow and a formal WCAG audit remain outstanding. Third-party map accessibility is not certified.

## Publication concerns

Use the exact page-by-page [content approval register](review/CONTENT-APPROVAL-REGISTER.md), not this visual assessment, for approval tracking. Existing generic slogans and unverified numeric claims are retained only in the local review copy and original snapshots; they must be approved, corrected or withheld before publication. No new claim has been certified. Original preserved material is in `review/stage2/originals/`.
