# Offline backup and recovery

The tool is implemented and tested with disposable records. Scheduling, encrypted off-site storage, retention, production permissions and recovery objectives still need an operations/privacy owner. It is not an unattended live-backup service.

## Create a snapshot

1. Stop **every** application instance and any process that writes to SQLite or deletes/uploads CVs. The `--offline` argument acknowledges this requirement; the tool cannot prove that other processes are stopped. Keep the service stopped until the command completes.
2. Set `UPLOAD_DIR` in the command environment to the actual private CV directory (default: `server/uploads`). This maintenance command does **not** load `.env`; pass the actual data directory explicitly.
3. Run `npm run backup -- create /absolute/data /private/backups/new-snapshot --offline`. The destination must not exist and must be separate from source data, uploads and the public tree. Never put backups in static hosting or commit them.
4. Run `npm run backup -- verify /private/backups/new-snapshot`. Restart the service after a successful snapshot or after investigating a failure. A failed snapshot removes only its newly created destination.

SQLite's backup API captures the database consistently, including WAL state. Referenced CVs are copied with SHA-256 checksums in a manifest. Missing documents, symlinked document files, unsafe file references, corrupted databases and checksum mismatches fail the operation. Active sessions are removed from the snapshot and the database vacuumed. Existing source data and sessions are unchanged. Unreferenced upload files and secrets are deliberately excluded.

The snapshot contains personal information in plaintext. New directories use mode 0700 and files 0600 where supported; configure Windows ACLs separately. Hashes detect accidental corruption, not a malicious replacement of both manifest and files. Encryption, restricted access and independently protected backup copies remain required operational work.

## Restore drill and recovery

1. Verify the snapshot, then run `npm run backup -- restore /private/backups/snapshot /private/recovery/new-directory --offline`. The tool refuses to overwrite an existing directory and validates integrity and checksums before copying.
2. Point an isolated server's `DATA_DIR` at the new directory and `UPLOAD_DIR` at its `uploads` child. Disable SMTP using explicit empty SMTP environment variables. Supply secrets from the approved secret store, not the backup.
3. Check record counts, authenticate afresh, retrieve a CV and verify unauthenticated access remains blocked. Confirm permissions and retention requirements. The tests exercise database/file recovery; they do not establish a production recovery time.
4. Only after an authorised operational decision, stop the production service, switch its storage configuration, validate and restart. This document does not authorise deployment or an actual production switch.

`npm run test:storage` exercises backup, restore, excluded sessions, tampering, missing CV cleanup, overwrite protection and symlink rejection using temporary fixtures. `npm run test:all` also runs the existing API, authentication/security and in-memory email suites. No test sends an external email.
