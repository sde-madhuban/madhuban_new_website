# Production security review

Local code/configuration and targeted regression review, 5 November 2026. **Not a penetration test, security certification or production approval.** No live infrastructure or customer database was tested.

## Verified findings and remediation

Severity reflects potential impact and code evidence; an installed-package advisory is not proof that every vulnerable path is exploitable here.

| ID | Severity | Verified finding / evidence | Remediation and current status |
| --- | --- | --- | --- |
| SEC-01 | Critical advisory; deployment-dependent exploitability | Initial npm audit: 6 affected packages (1 critical, 3 high, 2 moderate); proxy-addr included IPv4-mapped trust advisory | Compatible updates plus Nodemailer upgrade and scoped Express qs override; final audit reports 0. Raw reports in `review/stage2/dependency-audit-*.json`. Native SQLite load and integration tests passed. |
| SEC-02 | Medium | Login and logout POST lacked CSRF tokens; status/delete already had them | Added login token, validation and error-page token preservation; authenticated logout now requires token. Session regeneration retained. Tested missing token rejection and valid flow. |
| SEC-03 | Medium | Admin delete relied on inline `onsubmit=confirm`, blocked by the existing no-script admin CSP | Replaced with authenticated server-rendered confirmation GET and existing CSRF-protected POST. Tested confirmation and deletion against temporary records. |
| SEC-04 | Medium | Admin pages/downloads lacked explicit no-store | Added `Cache-Control: no-store` and X-Robots-Tag on admin routes. Confirmed on dashboard and authenticated CV responses. |
| SEC-05 | Medium | Combined/dev logs included original URLs; an admin search query can contain personal information | Structured method/path/status/duration logging omits query strings, referrer, user agent and body. Test sentinel absent from captured logs. Error logs now record codes instead of potentially sensitive full messages/stacks. |
| SEC-06 | Medium | Failed DB insertion left uploaded CV on disk; client MIME/extension were trusted; multipart fields/parts were not bounded | Clean up on save failure; require matching MIME/extension and PDF/OLE/ZIP signatures, bounded fields/parts/field size, retain 5 MB limit. Read errors handled. Spoofed/oversize/overpart rejection tested. Signature check is not a document parser or malware scanner. |
| SEC-07 | High if misconfigured | Configured data/upload path could point into the static public tree | Resolve paths and reject public descendants before opening DB/creating uploads. Upload directory creation uses restrictive permissions. Follow-up resolves existing symlink ancestors, rejects public-tree aliases and symlinked SQLite files, and rejects symlinked CV downloads. Existing directory permissions and concurrent filesystem tampering still need deployment review. |
| SEC-08 | Medium | Public CSP optional; runtime Tailwind required unsafe-eval/inline scripting; inline hover/location handlers existed | Removed runtime compiler; local base stylesheet, external JS/CSS handlers. Production always enforces self-hosted scripts, no script attributes/eval, no object embedding, restricted base/form destinations. Inline **styles** remain allowed to preserve existing page markup. |
| SEC-09 | Medium; topology-dependent | Production implicitly trusted one proxy; wrong topology can corrupt IP/rate-limit and secure-cookie behaviour | Removed implicit trust; require explicit non-negative hop count. Deployment must verify actual hops and restrict direct origin access. Existing .env was not silently rewritten. |
| SEC-10 | Medium | Permissive email validation admitted structured mailbox syntax; non-string fields were coerced | Accept a single ordinary email addr-spec; reject object/array field coercion. Nodemailer transport disables remote/file content access and has bounded timeouts. Internationalised/quoted mailbox support is not claimed. |
| SEC-11 | Low–medium functional | A 200 HTML response could be interpreted as successful form delivery | Only explicit JSON success completes the UI; unexpected responses keep entered details and announce failure. Persistent success status added. |
| SEC-12 | Low | Structured admin search query could reach `.trim()` on a non-string | Normalise admin filter values to strings; malformed query shapes no longer reach search as objects. |

No new application dependency was introduced. `npm audit fix` updated compatible installed versions and the lockfile. Nodemailer moved from 6.10.1 to 10.3.1 to remove remaining advisories; its SMTP interface is retained and in-memory MIME tests passed. Express remains 4.22.2 with scoped qs override `^6.16.2`; Multer 2.5.0, Morgan 1.12.1, proxy-addr 2.0.8 and better-sqlite3 12.11.1 were installed. Runtime minimum now reflects Node >=20; `.nvmrc` remains 24. Confirm the deployment runtime before installing this lockfile.

## Controls inspected and preserved

- Constant-time credential comparison, login rate limiter, session regeneration on login, HTTP-only/SameSite-lax session cookie, production secure-cookie default and SQLite session store.
- All admin data/status/delete/CV routes require authentication. Public health reveals only liveness.
- SQL statements use bound parameters. Admin and email HTML encode dynamic values. CV filenames are server-generated and resolved via basename; downloads are attachments through authenticated routes, not static URLs.
- Public parser size limits, shared per-process form rate limiter, honeypot, schema field allowlist and input length caps remain. Added multipart bounds do not change valid form fields.
- Helmet headers, strict admin CSP, public CSP, HTTP status handling, graceful shutdown/checkpointing.
- Emails remain best effort: failed email does not lose a persisted submission. This preserves behaviour but does **not** guarantee delivery.

## Remaining risks / recommendations (not fixed or not verified)

| Risk / recommendation | Priority | Required evidence / owner |
| --- | --- | --- |
| Malware scanning/quarantine and full document validation absent; DOCX signature proves only ZIP container and OLE signature is shared by Office types | High, launch risk decision | Infrastructure/security owner must implement scanning or approve a documented restricted handling process; never open untrusted CVs on an unmanaged workstation |
| Database/upload/session storage permissions, encryption, disk quotas and symbolic-link safety depend on host | High | Operations verifies non-public persistent mounts, least privilege, capacity monitoring and backup encryption |
| Offline backup/restore tooling is now implemented; scheduling, off-host copy and production whole-service restore remain unverified | High | Operations signs off RPO/RTO and a restoration drill covering SQLite **and** CVs, SMTP configuration and secrets |
| SMTP failures only logged; no durable retry/outbox | Medium | Operations validates real delivery, alerts and retry/manual follow-up procedure; code tests do not prove receipt |
| Rate limits use process memory and reset on restart; no shared fleet limiter or edge defence | Medium | Confirm single-instance deployment or add shared/edge controls after topology approval |
| Proxy and Secure-cookie overrides can be misconfigured | High, deployment-dependent | Verify TLS termination, exact trusted path, blocked direct-origin spoofing; do not use COOKIE_SECURE=false in production |
| Single shared env-configured admin credential, no MFA/per-user audit trail | Medium | Account owner approves access model, stores secret securely and rotates development credentials before release; consider individual admin accounts/MFA as separate work |
| External fonts, Unsplash and Google map remain third-party requests; inline styles still permitted | Medium | Confirm rights/privacy notices, provider availability and CSP allowlist; consider self-hosting approved fonts/images |
| Existing CSP allows HTTPS images broadly; static business content lacks approval | Medium | Narrow image policy after approved assets are finalised; do not mistake policy for a licence |
| No verified production ownership, DNS, HTTPS, canonical redirect or live CV download tests | Launch blocker | Infrastructure and company owners, see launch register |

## Backup and recovery procedure to approve

Use SQLite's consistent backup API for a live database, or stop writes and take a consistent offline copy; do not copy only a live WAL database file and assume it is complete. Pair the DB snapshot with the associated CV storage snapshot and a manifest of files. Protect snapshots as personal data. Set retention and deletion policies with the privacy owner. Restore into an isolated environment with SMTP disabled, run `PRAGMA integrity_check`, verify record counts and CV references, then test authenticated download and invalid-token rejection. A local temporary DB backup/restore test passed; no real customer data was backed up and no operational recovery time was certified. [SQLite backup guidance](https://www.sqlite.org/backup.html).

## Executed validation

- `npm test`: existing module smoke checks passed.
- `npm run test:engineering`: production-mode isolated server, all pages/legal/icon routes, three form APIs, persistence/CV rejection and protected routes passed.
- `npm run test:security`: login/logout/status/delete CSRF; session rotation/invalidation; stored HTML encoding; private CV attachment retrieval; no-store; confirmation; temporary SQLite backup/integrity/restore; invalid signature/oversize/multipart limits; parser limits; CSP; private-path isolation; rate limit; query redaction passed.
- `node tests/mailer.cjs`: new Nodemailer MIME output, encoding, reply-to/auto-reply routing, access restrictions and timeouts exercised entirely in memory. No external email sent.
- Syntax checks on changed server/client JavaScript passed. There is no configured compilation, linter or type checker; no nonexistent checks are claimed.
- Browser interactions and 112 layout checks passed with CSP enabled in the normal functional test context. Axe results are separate accessibility evidence, not a security test.
- `npm audit`: 0 reported vulnerabilities at review time. It is a point-in-time dependency check, not assurance that no vulnerabilities exist.

Reference guidance: [Express production security](https://expressjs.com/advanced/best-practice-security/) and [Tailwind's development-only Play CDN guidance](https://tailwindcss.com/docs/installation/play-cdn). The latter supports removing the runtime compiler, not a claim that the whole application is production-ready.

## Development follow-up

Added `server/storage.js` for canonical private-directory checks (including symlink ancestors), regular SQLite/CV file checks and owner-only database permissions on POSIX. New private directories use 0700. Host administrators must still control writable ancestors, existing directory permissions, encryption and quotas; the checks do not prevent races against a malicious process with filesystem write access.

Added [offline backup/recovery tooling and runbook](BACKUP-RECOVERY.md): consistent SQLite snapshot, referenced CV manifest/checksums, session exclusion, integrity verification and restore to a new directory only. Stop all writers first; the tool cannot verify that operational precondition. No customer-data snapshot or production restore was performed.

Corrected `.env.example` to use direct local access by default and automatic secure cookies in production. The actual `.env` and credentials are unchanged. Added `npm run test:all`, `test:storage` and `test:mailer`.
