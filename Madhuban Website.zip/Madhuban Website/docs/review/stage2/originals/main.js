/* ============================================================
   Madhuban Group — Page interactions
   Hero carousel · scroll reveals · count-up · generic sliders
   ============================================================ */
(function () {
  "use strict";

  function ready(fn) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }

  ready(function () {
    var motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!motion.matches) document.documentElement.classList.add("motion-ready");

    /* ---------- Scroll reveal ---------- */
    var reveals = document.querySelectorAll(".reveal");
    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
        });
      }, { threshold: 0.14, rootMargin: "0px 0px -40px 0px" });
      reveals.forEach(function (r) { io.observe(r); });
    } else {
      reveals.forEach(function (r) { r.classList.add("in"); });
    }

    /* ---------- Hero carousel ---------- */
    var hero = document.querySelector(".hero");
    if (hero) {
      var slides = hero.querySelectorAll(".hero-slide");
      var dotsWrap = hero.querySelector(".hero-dots");
      var idx = 0, timer;
      var paused = false, hovered = false, focused = false;
      var pauseButton = hero.querySelector(".hero-pause");
      var indexLabel = hero.querySelector(".hero-index");
      if (slides.length) {
        if (dotsWrap) {
          slides.forEach(function (_, i) {
            var d = document.createElement("button");
            d.className = "hero-dot" + (i === 0 ? " active" : "");
            d.setAttribute("aria-label", "Show slide " + (i + 1));
            d.setAttribute("aria-pressed", String(i === 0));
            d.addEventListener("click", function () { go(i); reset(); });
            dotsWrap.appendChild(d);
          });
        }
        var dots = dotsWrap ? dotsWrap.querySelectorAll(".hero-dot") : [];
        function go(n) {
          slides[idx].classList.remove("active");
          if (dots[idx]) dots[idx].classList.remove("active");
          idx = (n + slides.length) % slides.length;
          slides[idx].classList.add("active");
          if (dots[idx]) dots[idx].classList.add("active");
          dots.forEach(function (dot, i) { dot.setAttribute("aria-pressed", String(i === idx)); });
          if (indexLabel) indexLabel.textContent = "0" + (idx + 1) + " / 0" + slides.length;
        }
        function next() { go(idx + 1); }
        function reset() {
          clearInterval(timer);
          if (!paused && !hovered && !focused && !motion.matches && !document.hidden) timer = setInterval(next, 6500);
          if (pauseButton) {
            pauseButton.textContent = paused || motion.matches ? "Play" : "Pause";
            pauseButton.disabled = motion.matches;
            pauseButton.setAttribute("aria-label", motion.matches ? "Slideshow disabled by reduced motion preference" : paused ? "Play slideshow" : "Pause slideshow");
          }
        }
        if (pauseButton) pauseButton.addEventListener("click", function () { paused = !paused; reset(); });
        hero.addEventListener("mouseenter", function () { hovered = true; reset(); });
        hero.addEventListener("mouseleave", function () { hovered = false; reset(); });
        hero.addEventListener("focusin", function () { focused = true; reset(); });
        hero.addEventListener("focusout", function (event) { focused = hero.contains(event.relatedTarget); reset(); });
        document.addEventListener("visibilitychange", reset);
        motion.addEventListener("change", reset);
        reset();
      }
    }

    /* ---------- Count-up stats ---------- */
    var nums = document.querySelectorAll("[data-count]");
    if (!motion.matches && nums.length && "IntersectionObserver" in window) {
      var cio = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          var el = en.target, target = parseFloat(el.getAttribute("data-count"));
          var suffix = el.getAttribute("data-suffix") || "";
          var dur = 1400, start = null;
          function step(ts) {
            if (!start) start = ts;
            var p = Math.min((ts - start) / dur, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            var val = target * eased;
            el.textContent = (target % 1 === 0 ? Math.round(val) : val.toFixed(1)).toLocaleString() + suffix;
            if (p < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
          cio.unobserve(el);
        });
      }, { threshold: 0.5 });
      nums.forEach(function (n) { cio.observe(n); });
    }

    /* ---------- Generic drag/arrow slider ([data-slider]) ---------- */
    document.querySelectorAll("[data-slider]").forEach(function (root) {
      var track = root.querySelector(".slider-track");
      if (!track) return;
      var prev = root.querySelector("[data-prev]");
      var nextb = root.querySelector("[data-next]");
      function amt() { var c = track.querySelector(":scope > *"); return c ? c.getBoundingClientRect().width + 20 : 320; }
      prev && prev.addEventListener("click", function () { track.scrollBy({ left: -amt(), behavior: motion.matches ? "auto" : "smooth" }); });
      nextb && nextb.addEventListener("click", function () { track.scrollBy({ left: amt(), behavior: motion.matches ? "auto" : "smooth" }); });
    });

    var marquee = document.querySelector(".marquee");
    if (marquee) {
      var toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "btn btn-ghost";
      toggle.style.cssText = "display:block;margin:1.5rem auto 0;font-size:.75rem;padding:.65rem 1rem";
      toggle.textContent = "Pause logo animation";
      toggle.setAttribute("aria-pressed", "false");
      toggle.addEventListener("click", function () {
        var paused = marquee.classList.toggle("motion-paused");
        toggle.textContent = paused ? "Play logo animation" : "Pause logo animation";
        toggle.setAttribute("aria-pressed", String(paused));
      });
      marquee.after(toggle);
      function updateToggle() { toggle.hidden = motion.matches; toggle.style.display = motion.matches ? "none" : "block"; }
      motion.addEventListener("change", updateToggle);
      updateToggle();
    }

    /* ---------- Project filter ([data-filter-group]) ---------- */
    document.querySelectorAll("[data-filter-group]").forEach(function (group) {
      var buttons = group.querySelectorAll("[data-filter]");
      var itemsWrap = document.querySelector(group.getAttribute("data-filter-group"));
      if (!itemsWrap) return;
      var items = itemsWrap.querySelectorAll("[data-cat]");
      buttons.forEach(function (b) {
        b.addEventListener("click", function () {
          buttons.forEach(function (x) { x.classList.remove("active"); });
          b.classList.add("active");
          var f = b.getAttribute("data-filter");
          items.forEach(function (it) {
            var show = f === "all" || it.getAttribute("data-cat") === f;
            it.style.display = show ? "" : "none";
          });
        });
      });
    });
  });
})();
