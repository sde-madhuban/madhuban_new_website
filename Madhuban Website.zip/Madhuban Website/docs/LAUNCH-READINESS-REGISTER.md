# Launch readiness register

Updated 5 November 2026. **NOT approved for production. No deployment or indexing enablement performed. The SEO publication script was not executed in this review.**

Owner entries below identify the role required to approve; no individual or acceptance is inferred. “Local evidence available” is not a completed production condition.

| ID | Mandatory condition | Current evidence | Current status | Evidence required to close | Approval owner |
| --- | --- | --- | --- | --- | --- |
| L01 | Approved custom domain with verified ownership | No approved canonical domain or registrar evidence supplied | BLOCKED | Approved hostname, registrar/DNS ownership proof and hosting account control | Company domain owner + operations |
| L02 | HTTPS and canonical hostname behaviour | Local HTTP testing only; explicit proxy configuration and secure-cookie default inspected | BLOCKED | Valid certificate/chain, HTTP→HTTPS and chosen www/non-www redirect tests, exact proxy topology/direct-origin restrictions, secure session cookie observed | Operations/security |
| L03 | Approved Privacy Policy and Terms | Two functioning extensionless routes and marked noindex drafts | BLOCKED | Authorised final legal text, entity/contact, providers/retention/rights processes, effective version and recorded acceptance | Legal/privacy owner + company authorised representative |
| L04 | Verified business content and image rights | Exact page-by-page register and preserved originals; stock URLs documented | BLOCKED | Source documents for every claim, relationship/brand permissions, image rights and authentic project identification or explicit approved illustrative treatment | Business/content owners + rights holders |
| L05 | Official favicon and metadata | Logo-derived icons, social asset and brand tags respond locally; screenshot inspected | LOCAL IMPLEMENTATION VERIFIED; APPROVAL PENDING | Brand owner approves derivative icon/crop; canonical/OG URLs on approved host, real browser/social fetch verification | Brand owner + frontend + operations |
| L06 | No unwanted optional AI attribution | No such attribution found in source/rendered public pages; HorseTech retained | LOCAL CHECK PASSED; HOST REVIEW PENDING | Verify production platform inserts none; confirm contractual status of existing provider credit | Company/contract owner + operations |
| L07 | Production contact and careers submissions | All three APIs tested with isolated DB; valid/error/UI flows exercised; no outbound email | BLOCKED | Authorised test on actual host, stored enquiry/contact/CV, received team notification and configured auto-reply, error/rate-limit behaviour and cleanup | Operations + business inbox/HR owners |
| L08 | Production storage/retrieval/access controls | Local auth/CSRF/download/no-store/private URL tests passed; offline backup/restore CLI and isolated recovery tests implemented | BLOCKED | Persistent private mount and access evidence, actual CV retrieval, authenticated admin lifecycle, backup schedule/off-site protection, CV+DB restore drill, malware handling decision | Operations/security + HR/privacy |
| L09 | Intentional robots/sitemap/indexing | robots still Disallow: /; legal drafts noindex; publication helper untouched | PRE-LAUNCH RESTRICTIONS PRESERVED; BLOCKED FOR LAUNCH | Explicit indexing/SEO authorisation after all other gates; approved origin; generated and validated sitemap/canonical/robots; private staging access where necessary | Company release owner + SEO + operations |
| L10 | No known critical functional/security defects | Local remediations/tests and zero final npm audit findings; residual risks documented | LOCAL FINDINGS REMEDIATED; PRODUCTION GATE OPEN | Operational security review, upload/malware decision, runtime compatibility, alerts, CSP and proxy tests on real deployment; closure or signed risk disposition | Security/engineering + release owner |

## Content sign-off work queue

[CONTENT-APPROVAL-REGISTER.md](review/CONTENT-APPROVAL-REGISTER.md) and its JSON companion contain the exact text/assets, page, source file/selector, existing evidence, verification status, proposed approver, corrective action and blocker flag. Entries are intentionally unapproved. The source implementation establishes what is shown, not whether business statements are true. Shared footer/contact information appears per page; approval can reference one authoritative source across repeated records.

Key unresolved concerns from rendered review:

- The CSR tree-plantation card uses a solar-panel photograph. Replace only with an authentic approved asset or approve withholding the image; no substitute has been invented.
- Stock buildings/houses/restaurants appear alongside named Madhuban projects and alt text. Their rights and contextual accuracy must be resolved.
- 1997, 27+, 50+, 7, floor areas, Grade A, 24×7, awards, client relationships, leadership quotes/titles and future 5-star claims require documentary approval. Count-up animation was removed; the original static values are not thereby verified.
- Generic existing promotional wording remains in the local review copy; the established hero headline is preserved. Approve precise factual replacement wording where required.
- Official social/film destinations remain absent and withheld; original fragments are preserved. A release can omit these absent features rather than invent destinations.
- Legal drafts reflect code-confirmed flows only; real hosting/email/backups and company policies remain unverified.

## Review evidence and constraints

- [Visual quality review](VISUAL-QUALITY-REVIEW.md): all 14 pages at mobile/tablet/desktop, changes and remaining authenticity/design issues.
- [Production security review](PRODUCTION-SECURITY-REVIEW.md): verified findings versus recommendations, severities, fixes, tests and remaining risks.
- `review/stage2/`: audit JSON, before/after axe results, final rendered contact sheets and original public-content snapshots. No secrets, credentials, real submissions or uploaded CVs are included in these artifacts.
- Automated checks do not replace legal/brand acceptance, production DNS/HTTPS tests, live email evidence, screen-reader/device testing or an operational restore drill.

The next step is owner evidence collection and operational review. Production launch authorisation should be requested only after all critical conditions are satisfied; it is not requested now.

## Remaining development and operational decisions

Local follow-up adds symlink-aware private-storage validation and tested offline backup/recovery commands; see [runbook](BACKUP-RECOVERY.md). This does not close L08. Production scheduling, encrypted off-host copies, restore timing and host permissions require an approved environment.

Unimplemented options remain explicit: durable SMTP retries/outbox, malware scanning/quarantine, shared fleet rate limiting and individual admin accounts/MFA. These require delivery/retention policy, scanner/hosting services or an approved access model; current best-effort mail and single-admin functionality are preserved. They have not been represented as completed. No legal, content, rights, domain or live-delivery approval has been inferred.
